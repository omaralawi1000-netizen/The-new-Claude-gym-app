FAIL. Score: 8.8 / 10.

# Rope Pushdown, clip 1: judge verdict (judge round 7)

The round-6 wrist pinhole is fixed. Nothing bright is left in the far wrist on any frame, the eased-back far wrist looks natural,
and the f25 cable crossing is fine in motion. The 2-D paint-in itself is clean: I can't see a smudge or an edge.

It still fails, for the same class of defect as round 6. **Background still shows through between the far fingertips and the glute
as near-white 1-2 px specks on f42, f62, f66 and f67.** Your scan missed them. On f62-67 they sit on each side of the three painted
frames (f63-65), so the paint-in shortens the sparkle but doesn't remove it. The sequence reads f62 speck, f63-65 dark, f66-67 speck,
at the moment the far fist turns past the hip. At x4 that twinkles.

## Why your scan missed them
`speckscan.py` keeps 8-connected blobs of luma > 120 up to 16 px. The glute next to the fingertips is lit at 116-143. So a background
hole that touches the glute joins the glute's big light region, goes over 16 px, and is thrown out as "open background". The holes
I found sit exactly on that boundary, at x 320-322, with glute pixels at 120-143 next to them.

## Pixel evidence (both encodes agree, so the specks are in the source and not codec noise)
| Frame | Where (native) | Peak (mp4 / webm) | Size |
|---|---|---|---|
| f42 | 319-320, 325-326 | 201 / 176 | 2x2 |
| f62 | 320-321, 334 | 221 / 214 | 2x1 |
| f66 | 320-321, 324-325 | 224 / 226 | 2x2 |
| f66 | 320-321, 327 | 187 / 193 | 2x1 |
| f67 | 321-322, 321-322 | 209 / 203 | 2x2 |
| f67 | 320-321, 326-327 | 231 / 237 | 2x2 |

The background is about 240, the dark fist 20-60 and the glute 110-130. Crops: scratchpad `judge-r7/push-specks-x8.png`,
`push-wedge-62-73.png` (mp4) and `push-wedge-62-73-webm.png`.

## What I looked at myself
- All 130 frames from both `pushdown-clip-1.mp4` and `.webm`, and the lossless keys and sheets in this folder.
- The far hand every frame f44-73 at x3, x6 and x8. Both wrists at x3 on every key frame.
- A whole-frame isolated-bright-pixel scan on every frame (pixels above 180 with at most 6 bright pixels in a 9x9 window and at least
  60 dark ones), plus a looser scan in the far-hand box (above 165, with at least 4 pixels below 90 within 3 px). The only hits that
  aren't highlights or open-background gaps are the fingertip-glute specks above.
- The light gaps at the elbow and lat on f25, f28-29, f80-81 and f86 are the real gap between the arm and the torso opening and
  closing. That's correct, not a defect.
- **Motion:** blurred per-step change. There's a small hitch at f62-67 (far box 1.15 → 1.77 → 2.44 → 2.45 → 1.75 → 1.97 → 2.57) as the far
  fist unwinds from the wrist ease-back (`wrist_l` -6.3 at f62 → 0 at f70) while the push returns. You can see the fist rotate quickly
  across f62-66. It isn't a pop, but it's the least smooth stretch of the clip.

## Item by item

| Check | Finding | Verdict |
|---|---|---|
| Wrist pinhole (r6 must-fix) | Nothing bright in either wrist on any frame f20-90. The hidden fillers worked. | **Fixed.** |
| Far wrist ease-back 6 deg | It reads as the fist relaxing at the hip. It looks natural on the stills, a little quick on the return (f62-66). | **OK.** |
| Paint-in f47, f57-59, f63-65: invisible? | At x8 I see no smudge, no flat patch and no hard edge. The painted pixels match the dark rim. **But:** (a) next to f47, frames f46 and f48 keep a mid-grey pocket at 126-143 that the threshold doesn't count, so f47 is very slightly darker than its neighbours (x8 only). (b) f62 and f66-67 still have true background specks right beside the painted f63-65. So the patch is invisible as a patch, but it doesn't make the sequence clean. | **Paint-in clean. The result doesn't pass.** |
| Fingertip-glute background specks | f42, f62, f66, f67 (table above). | **Must-fix 1.** |
| Cable at f24-25 (25 px against 24) | The clip slides behind the deltoid in 2 frames and never rests on the outline (`cable-crossing-f22-29-x3.png` and my frames). | **Accepted.** |
| Far cap / far end | Held in the fist throughout. No floating end. | **Pass.** |
| Hands on rope, glow, red, loop | Clean. The loop seam step is the encoder keyframe only. | **Pass.** |

## Flaws, ranked
1. **Near-white background specks between the far fingertips and the glute, f62, f66, f67** (cluster around the painted frames), and **f42** (isolated). 2x2 px, peaks 200-237. Blocks.
2. Quick far-fist rotation on the return, f62-66 (a motion hitch in the far box). Nice-to-have.
3. A mid-grey (126-143) pocket at the fingertip on f46 and f48 against the painted f47. x8 only. Cosmetic.

## What must change to pass
1. **Fix the scan first, so it can find these.** Count a speck as background when it is near-neutral and brighter than the local body,
   not by connectivity. For example: luma > 170 (or within 40 of the background value), with dark fist pixels (< 90) within 2 px.
   Ignore whether it joins the glute through pixels in the 120s. Run it on every frame f20-90 in the box 270-390 x 230-400. It must
   find f42, f62, f66 and f67 before you trust it.
2. **Close them in geometry, preferably.** The pocket is between the fingertips and the palm/rope as the fist meets the hip
   (f42, f57-67). Use a hidden dark filler like `FIST_SEPTUM` but on the finger-to-palm gap (fingertip pads to rope, ≤4 mm), or curl the
   far fingers 3-5 deg more for f40-70.
   - If you keep a 2-D pass, it must cover every frame the fixed scan flags (at least f42, f62-67). Show one strip, f40-72 at x8,
     with no light speck on any frame and no frame darker or lighter than its neighbours at that spot.
3. **Optional, same render:** stretch the `wrist_l` return from f62-70 to about f60-74, so the fist doesn't spin on the way back.
4. Re-run FARDIAG, contact and tilt on every frame after any far-hand change.

## Taken from the thread, not re-run (no Blender here)
- The FARDIAG, CABLEDIAG, contact and tilt numbers. I parsed the README. The pixels agree, apart from the fingertip specks.

## Can it ship?
**No.** Close the fingertip-glute specks on every frame and send the f40-72 x8 strip. I expect the next clip to pass if that strip is clean.
