# Rope Pushdown, clip 1 (after judge round 6 on the r5 stills)

Clip: `pushdown-clip-1.mp4` / `.webm` (130 frames, 30 fps, 4.3 s loop, 960x640). Code: `../../code-r7/` (`rope30.sh` renders it, `rope34.sh` does the pinhole pass).
Everything below is self-checked, not judged.

## Must-fix 1: background pinhole through the far wrist (f36, f72, likely f30-80)
- **Cause (PICKDIAG at 320,312 f36):** a tunnel between the palm and the rope, plus the forearm-to-hand seam opening on the turned-in wrist.
- **Fix, two hidden fillers** that render the same as the hand's own dark skin:
  - **Fist septum** (`FIST_SEPTUM=1`): thin discs every 3 mm along the grip. Each disc reaches from the rope surface out to 0.7x the palm gap, and only where that gap is 4 mm or less, so it closes the tunnel without ringing the bare rope.
  - **Wrist core** (`WRIST_CORE=1`): a tube along the forearm axis, from 12 mm inside the hand to 45 mm up the forearm, at 0.8x the inside of the skin. It fills the seam.
- **Far wrist eases back 6 deg through the lockout** (`wrist_l`: f33 0 → f41 -6 → f62 -6.3 → f70 0). This keeps the fist's curl off the glute outline. `far-hand-r5-vs-clip-f036-048-072-x3.png` shows the r5 stills next to the clip frames.

## The pass test: no pixel above 150 inside the far hand/wrist, every frame f20-90
- **Raw render (`far-hand-pinhole-scan-raw.txt`):** the wrist pinholes are gone. 7 frames still had a small light pocket, all **between the far fingertips and the hip**, not in the wrist:
  - f47 and f57-59: up to 151-163, 11-15 px;
  - f63-65: up to 189-213, 2-9 px. This one is real background. The fist crosses the glute outline there, and for 3 frames the fingertip bumps close a tiny notch against it.
- **Please look: I closed those 7 with a 2-D cleanup pass, not geometry** (`holefill.py`, log `holefill-log.txt`).
  - It takes exactly the scan's blobs (8-connected, luma > 120, at most 16 px, holding a pixel > 150, cut off from the open background) inside the far-hand box 270-390 x 230-400.
  - It paints each one in from its dark rim, outside-in. No other pixel in the frame changes.
  - Before and after: `far-fingertip-hip-pinholes-raw-vs-filled-x6.png`.
  - **Final scan (`far-hand-pinhole-scan-final.txt`): 0 frames, f20-90.**
  - Geometry I tried first for the pocket, none clean: wider and tighter far abduct, grip +0.04, inflating the fingers, a web filler between the fingers, and holding the wrist longer (f74 then floated). If you'd rather not have a 2-D pass, say so and I'll keep working on the pose.
- **Close-ups (`hands-closeups-clip-build.jpg`):** both hands, two views each (lc/la far, rc/ra near), f0/20/36/48/64/72, on the clip build. No white sliver at either wrist, including ra f36/f48 where you saw the near-wrist mark. The light gaps that remain are between forearm muscle strands, and the near fist's own opening round the rope.
- **f48 speck at about (318,330):** the raw scan finds nothing at f48. The nearest is f47 at (315,331), 151, which the cleanup pass closes.

## Far end (`far-end-log.txt`, FARDIAG, every frame)
- 0 floating frames out of 130 (FAR_FIST_MIN 150).

## Contact (`contact-log.txt`, all 130 frames)
- **Hands:** 0 hand-skin points inside the rope, worst clearance 0.3 mm.
- **Rope shape:** ROPESTRAIGHT 0.00 mm, ROPEMONO 0.0 mm.
- **Rope vs body:** 0 crossings, at least 5.9 mm. Rope vs head at least 133 mm.

## Cable at f25 (`cable-log.txt`, CABLEDIAG, every frame; `cable-crossing-f22-29-x3.png`)
- Flagged for the clip: one near-outline run of **25 px at f25** (limit 24). Every other frame is ok.
- It is the clip sliding behind the deltoid. The cable is clear by 21 px at f20 and 6 px at f23. It touches the outline on f24-25 and is behind the shoulder from f26. So the clip crosses the outline once, in two frames, rather than resting on it.

## Other checks
- **Tilt (`tilt-log.txt`, every frame):** max |2nd diff| 0.12 (far, f26) / 0.009 (near); no run of 3 identical non-zero values.
- **Motion (`clipcheck.txt`):** no spikes; loop seam 0.063 against a per-step median of 0.183.
- **Colour (`colour-log.txt`):** red core 221-224/46-48/29-30, lightness 0.541-0.543, the same as the r5 stills.
- **Clip vs the r5 stills:** f0 0 px differ, f20 1 px, f72 45 px, f36 746 px and f48 1295 px. The last two are the far wrist ease-back and the fillers.

## Files
- `pushdown-clip-1.mp4`/`.webm`, `clip-f000/020/036/048/072.png`, `clip-every-10th-frame.png`.
- Sheets: `far-hand-r5-vs-clip-f036-048-072-x3.png`, `far-fingertip-hip-pinholes-raw-vs-filled-x6.png`, `hands-closeups-clip-build.jpg`, `cable-crossing-f22-29-x3.png`.
- Logs: `far-hand-pinhole-scan-raw.txt`, `far-hand-pinhole-scan-final.txt`, `holefill-log.txt`, `far-end-log.txt`, `contact-log.txt`, `cable-log.txt`, `tilt-log.txt`, `clipcheck.txt`, `colour-log.txt`.
