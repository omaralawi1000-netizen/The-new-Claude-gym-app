# Rope Hammer Curl, clip 1 (after the round-5 stills pass)

Clip: `hammer-clip-1.mp4` / `.webm` (130 frames, 30 fps, 4.3 s loop, 960x640). Code: `../../code-r6/`. Script: `rope23.sh`.
Everything below is self-checked, not judged.

## Your two clip conditions
1. **Settings come from the move file, not a shell line.**
   - `motions/hammer.py` now has an `ENV` block. It holds the rope20.sh `HM` line plus the shared env (BLOOM_FORE, GLOW_OUTLINE 0.45, OUTLINE_T 0.4, FORE_NOLIGHT, ...).
   - `render8.py` applies it as defaults (`os.environ.setdefault`), so a script export still wins.
   - `rope23.sh` exports nothing but `MOTION=hammer`.
2. **Contact on every frame:** `contact-log.txt` covers all 130 frames, in 3 parallel chunks on the clip build.
   - **Hands:** 0 hand-skin points inside the rope, worst clearance 0.3 mm.
   - **Rope shape:** ROPESTRAIGHT 0.0 mm. ROPEMONO worst back-step 0.6 mm (one frame; it was 0.5 in round 5).
   - **Rope vs body:** 0 crossings, rope-to-body at least 2.1 mm.
   - **Rope vs head:** at least **103 mm** (f61-62). See "What changed" for why this dropped from 171 mm.

## Tilt (`tilt-log.txt`, TILTDIAG, every frame)
- **Max |2nd diff|:** 0.110 / 0.106 deg/f² (pass 0.15).
- **No run of 3 identical values.**
- **One change was needed.** On the clip build the bottom of the rep reaches phi 108.2 deg. With the smoothstep span of 63 that saturated, and held -14.000 for 7 frames (f123-129 and f0-2).
  - `TILT_SPAN` is now 66 for the hammer (63 for the pushdown).
  - The tilt now creeps -13.9 → -13.95 through the hold, as round 5 intended ("saturates only past the largest phi").

## What changed from the stills you passed (please look)
`stills-r5-vs-clip-f030-f055.png`: round-5 key on the left, clip frame on the right.
- **My round-5 claim was wrong.** I wrote that the "farthest clip" solve left the hammer's clip heights unchanged. It does not.
  - The round-5 keys (`hm18k`) and logs were rendered with the old bisection.
  - The clip uses the farthest-root solve: the cable pulls the clip as far toward the pulley as the strands reach.
  - At f55 the clip sits 286 mm below the exits, against 217 mm before. The V is longer and both strands run straight, with no wrap under the near fist.
  - f0 is unchanged (139 px differ).
- **This is the physically right taut rope,** and the pushdown needs the same solve. So I kept it rather than give the hammer its own solver.
- **The cost:** the near strand passes closer to the collarbone at the top (rope-to-head 103 mm, still clear). Your nice-to-have 1, the cap on the collarbone, is the frames to watch (f50-65).
- **The forearm angle differs a little too,** because the grip follows the rope line through the forearm twist.

## Colour (`colour-log.txt`)
- **Red:** core 220-222/48-49/31-32 and lightness 0.553 on all three keys (round 5: 220-222/47-49/31-32, 0.544-0.554).
- **Forearm boxes, on the clip frames:**
  - **f30 box:** reads +8.8 overall (was +11.0).
    - Rows 232-236 are the lit brachioradialis edge (+46 → +6).
    - Rows 237-244 read -2.7..+1.7.
  - **f55 box:** reads +6.9 overall. The forearm sits a few px lower, so the box now catches two things:
    - Rows 180-189: the biceps halo on the torso gap (PICKDIAG: body under-layer) and the 1-2 px forearm edge.
    - Rows 190-214 read **0.0**.

## Motion checks (`clipcheck.txt`)
- **Spikes:** none.
- **Loop seam:** 0.134, against a per-step median of 0.497.
- **Static area:** the 99.9th percentile reaches 39 levels (the curl's was 16). The "static" mask is the bottom 38% of the frame, and on this move it holds the moving cable and the low pulley run.
- **Framing (`framing-log.txt`):** the near fist is at least 148 px from the column, and the midpoint is +7.

## Files
- **Clip and keys:** `hammer-clip-1.mp4`/`.webm`, `clip-f000/030/055.png` (clip frames = keys), `clip-every-10th-frame.png`.
- **Close-ups:** `hammer-hands-closeups-clip-build.jpg` (both hands, f0/30/55/70, clip side and from below).
- **Logs:** `contact-log.txt`, `tilt-log.txt`, `framing-log.txt`, `colour-log.txt`, `clipcheck.txt`.
