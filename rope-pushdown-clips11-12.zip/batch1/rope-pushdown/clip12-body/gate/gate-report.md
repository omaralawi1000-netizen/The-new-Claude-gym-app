# Gate report: pushdown_d

**RED: fix before any judge** (1 fail, 12 pass, 2 for a human eye)

- PASS  Pixel stage ran on every frame (holefill3 made all final frames): raw 130, final 130
- PASS  No diagnostic job crashed: none
- PASS  Hands on the prop (contact): inside 0, worst clearance 0.3 mm
- PASS  Rope strands run only toward the clip: 0 strand-frames
- PASS  Rope straight past the fist: 0 strand-frames
- FAIL  Far rope end held (nothing floating): 2 floating frames
- PASS  Cable clear of outlines: tangent runs 0, longest 12 px
- PASS  Fist tilt smooth (<= 0.15 deg/f^2): max 0.144
- PASS  Near fist clear of the machine: worst gap 229 px at f95
- INFO  Far-limb slivers (judge decides size): frames 75,76,95,12,15,73,74,39,98,99
- PASS  Background specks after the fill (speck2h): 0 frames
- INFO  Dimmed gap ends (check in sequence): frames 23,24,31,83,84,85,88
- PASS  No pops or flicker (clipcheck): []
- PASS  Motion smooth, no hitch (blurred steps): SMOOTH steps 130 median 0.633 max 1.656 | seam 0.089 vs neighbours 0.120 | spikes none
- PASS  Pixel scans saw every frame: speck2h 130 frames, clipcheck "frames N" ok

Logs and crops: this folder. Final frames: ../pushdown_d_final/
