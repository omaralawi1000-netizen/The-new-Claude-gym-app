# EZ-bar Curl clip 1 (built from the round-2 stills that passed)

- `ez-clip-1.mp4` / `.webm`: 130 frames, 4.3 s loop, 960x640, fast mode (16 spp + OIDN). Same build as round 2: scene12.blend, level hinge plus abduction solve, EZ bar fitted to the hands, 22° forearm turn.
- `r15-vs-ez-side-by-side.mp4`: the live barbell curl (left) and the EZ bar (right), synced frame for frame. This is the page's main view.
- `clipcheck.txt`:
  - no spikes;
  - static-area change mean 0.063, max 0.103;
  - loop seam 0.249 vs a median step of 0.926 (smooth).
- `measure.txt`: bar max 7.97 px/f at f32 (rule: 8-9 or less), and every body landmark under 0.5 px/f.
- `ez-hands-final-build.jpg`: grip close-ups rendered on the final build at f0, f30, f55 and f70 (each hand, clip view and from below). They match the round-2 close-ups that passed.
- `poster-f030.png` (your pick, the W reads) and `poster-f000.png` (the bottom, like the curl's poster).
- The contact log is `../ezgrip-log.txt`: 0 inside on every frame, worst clearance +0.3 mm.
