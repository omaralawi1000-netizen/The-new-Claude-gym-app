PASS. Score: 9.2 / 10. No must-fix.

# Rope Hammer Curl, clip 3: judge verdict (judge round 8, rope realism)

This is the first version of the hammer where the rope behaves like a rope on a real cable machine. The cable drops almost
vertically from the clip to a wheel just past the toes. At the top, the V hangs from the bottom of both fists, with the knobs
over the thumbs, and the clip sits well below the hands. At the bottom, the rope hangs in front of the thighs. Next to the clip 2
panel on the comparison sheet, the "stiff forward handle" is gone. The pinholes are gone. The gap fades are smooth in sequence.
I found no new speck, pop or jitter. What is left is small physical and cosmetic polish, listed below. None of it blocks.

## What I looked at myself
- All 130 frames extracted from `hammer-clip-3.mp4`, plus all 130 from `.webm` for the seam. Also the lossless keys
  `clip-f000/030/055.png`, `real-vs-clip2-vs-clip3.jpg` and `clip-every-10th-frame.png`. All 130 clip 2 frames were used for one comparison.
- My crops (scratchpad `/tmp/claude-0/-home-user/7ea2b97e-9085-5fc7-9c1d-d7bb5f376d24/scratchpad/c/`; nothing of mine is left in this folder):
  - `hands0.png`: hands at f0/f15, x4.
  - `up.png`: up-swing f0-70, x2.
  - `capA.png`, `capB.png`, `capC.png`: the cap through both crossings, every frame, x4.
  - `gapseq.png`: the wrist / far-forearm gap f24-32 and f88-96, x6.
  - `dimA.png`, `dimB.png`: all seven dimmed gap ends with 3-4 neighbours each side, x6.
  - `pulley.png`: the floor arm, x3.
  - `key0hands.png`, `key55.png`: lossless keys, x6 and x3.
  - `seam.png`: f124-f2, x3.
  - `knee.png`, `kneecmp.png`: the leg gap, clip 2 against clip 3.
- **My own pinhole scan, every frame, whole figure** (box 250-560 x 40-620, wider than the builder's 300-500 x 100-420):
  8-connected luma > 200, at most 16 px, a pixel under 150 within 2 px.
  - **Hands, rope, cap and gap zone:** 0 background pinholes.
  - **What it does flag:**
    - lit highlights at 200-209, mostly the near deltoid ridge at x 289-312, y 170-203, which is skin;
    - the closing ends of the wrist gap (f30 at 389,245, max 203; f93 at 387,248, max 205), which are a real gap fading, see Q3;
    - a 1-2 px slit between the knees (336, 430-445) at f20-27 and f127-1. This is real background between the legs as the gap
      there opens and closes. Clip 2 does the same thing frame for frame (same luma curve: 209/5 px → 0 → 250/100 px), so it is
      not new and not a pinhole.
- **Red specks:** isolated R-G > 60 blobs ≤ 6 px with no other red within 5 px: 0 frames.
- **Motion:** blurred per-step change in the hand box (280-480 x 100-460), every step. It is smooth, with one hump on each half-rep
  and no spike. The top turnaround is 0.63/0.42/0.28/0.53. At the seam, the slow settle (0.23-0.37, f118-129) goes straight into a
  0.6 start (f0-2). In the mp4 the step at 129→0 is 0.79, part of which is the encoder keyframe (static area 0.03). In the webm it
  is 0.56. In the x3 sequence f124→f2 I see no hitch, so it passes.

## Questions from the builder

**1. Do the side views match the real reference frames?** Yes, closely enough for a stylised figure.
- **Top (f55 key against HSC top and Harrison front):**
  - The rope drops from the bottom of both fists, and the knobs sit over the thumbs (Jay/HSC).
  - The strands form a narrow hanging V to a clip at about navel height, and the braid shows.
  - The cable runs straight down to the wheel.
  - This matches the real frames.
- **Bottom (f0 key against HSC bottom):**
  - The fists sit in front of the hip and thigh, and the rope hangs below them to a clip at mid-thigh, with a vertical cable.
  - Two differences from HSC, both small:
    - The V is wider: the fists are about a fist-width apart, where in HSC the hands nearly touch.
    - The far strand leaves the far fist heading toward the body, then curves about 45° toward the clip (see nice-to-have 1).
  - Real lifters vary here: Buff Dudes holds the fists wider, at the sides of the thighs. So this still reads as a real rope hammer curl.
- **Middle (f30-40):**
  - The forearms are level and the V opens below the fists to a clip at hip height.
  - The cable stays vertical.
  - Nothing points forward or reads as a rigid bar.

**2. The cap crossing the torso outline, f25-46 and f77-95. Natural or a glitch?** Natural. In sequence there are three phases:
- f25-31 and f90-95: the near cap passes in front of the far forearm, at its lower edge. Background shows around the far
  forearm, which is why CAPDIAG counts it. It reads plainly as the near fist in front of the far arm.
- f32-41 and f80-89: the fist is out in front of the torso while the forearms are level, so the cap is over clear background.
  This is a fist held out in front of the body, which is what happens.
- f42-46 and f77-79: the cap slides onto the pec. At f43 and f79-80 its top or side runs along the pec/side outline for about
  one frame each, moving 3-4 px a frame.
- It never stops on an outline. The written rule (1-5 frames) is exceeded in count, but what is on screen is one continuous
  pass each way, the same as a real fist travelling in front of a torso.
- Accepted.

**3. Seven dimmed gap ends (luma 162-191). Visible or popping?** None pops.
- f13 and f110 (thumb vs forearm, about 384,318): the wedge fades in over f13→f14→f15 and out over f109→f110→f111, and each
  step grows or shrinks steadily.
- f26 (417,257) and the wrist gap at 378-402 x 236-256:
  - closing f24-31: >200 px count 108/111/110/90/60/1/2/0, so it shrinks steadily;
  - opening f91-96: 0/0/1/44/68/73.
- f38-39 and f81-82 (cap neck vs chest, 390-396 x 200-208):
  - These show as a small mottled light-grey patch left of the cap neck for 2 frames each way.
  - At x6 it reads as a faded gap, not a white speck. At 1x I can't see it.
  - It is the only one with any texture. See nice-to-have 3.

**4. Floor-arm pulley 22 cm past the toes, column 72 cm out. Does it read as real hardware?** Yes, with one detail off.
- What reads right:
  - A horizontal arm from a bracket on the column, a fork-hung wheel at its tip, and the cable on the wheel's front rim.
  - The wheel sits in the plane of the pull, and the cable wraps under it.
  - This looks like a floor-pulley extension on a functional trainer.
  - Keeping the column out of the space behind the fists is the right call: the fists never sit in front of the post.
- What is off: the return run of the cable goes from the bottom of the wheel diagonally through open air, below the arm, and
  ends at the side face of the bracket block (about 455-525 x 540-555). On real kit the cable runs along or inside the arm to a
  second sheave at the column. It is small at 1x, but a lifter would notice it. Nice-to-have 2.

**Fists close together in front of the thighs at the bottom?** Yes, in front of the hip and thigh.
- The gap between the fists is about 45 px in frame (about a fist width, roughly half the shoulder width in the same view).
- That is much better than clip 2's hip-width spread, and the strands hang rather than lying flat.
- Tighter would match HSC exactly, but it is not wrong.

## At rest against in motion
- **At rest (f0, f55 keys):**
  - The fingers wrap the rope, the knobs sit over the thumbs, and the braid reads at the top.
  - The glow edges are clean and the red is consistent.
  - The strands are straight under load.
- **In motion:**
  - The grip does not creep, the rope does not slide in the fist, and nothing appears or vanishes in a single frame.
  - The far-forearm red slivers are as disclosed and as in clip 2: f35-37 at about 380-395 x 214-220, and f85-86 under the near cap. Cosmetic.

## Must-fix
None.

## Nice-to-haves (in order of payoff)
1. **Far strand hook at the bottom (f0-22, f106-129; native about 418-440 x 318-348).**
   - The far strand leaves the pinky side heading toward the body for about 1-2 rope diameters, then curves about 45° to the
     clip. At x4 it reads a little like a bent hose. The near strand has a smaller version.
   - In HSC the rope leaves the fist already pointing at the clip.
   - Fix: a few degrees of ulnar deviation or wrist tilt on the far hand at the bottom, so the rope axis through the fist lines up
     with the pull. Ramp it over 20 or more frames and re-check tilt and ROPEMONO.
   - This is the last thing I would expect Omar to call "not how a rope works".
2. **Cable return path at the floor arm:** run the return along the underside of the arm, or add a small second sheave at the
   bracket so it doesn't end in mid-face.
3. **Cap-neck dimmed patch, f38-39 and f81-82 (390-396 x 200-208):** smooth it to a flat tone instead of the mottled dim, or let the
   gap close one frame earlier in the pose.
4. **Far-forearm red slivers (f35-37 and f85-86):** the same optional glow cut as clip 2.
5. **Fists slightly closer at the bottom** (abduct a further 2-3 deg) for an exact HSC match. Optional.

## Taken from the thread, not re-run (no Blender here)
- CAPDIAG, CABLEDIAG, FARDIAG, SLIVERDIAG, the contact and tilt numbers, and the ray masks behind "these are real gaps". The pixels agree with all of them.
- The 22 cm and 72 cm hardware distances. They look consistent with the foot size in frame.

## Can it ship?
**Yes.** It fixes the rope physics Omar objected to, it is clean at the pixel level, and the motion is smooth. Nice-to-have 1 is
the one worth doing if there is another pass.
