Some big files were cut into parts of 25 MB (name.part00, name.part01, ...).
To join them: in a terminal, run   cat name.part* > name   (Windows: copy /b name.part00+name.part01+... name).
Files that were cut:
./anatomy-proof/rig/scene12.blend
./anatomy-proof/batch1/rope-hammer-curl/clip3/approved/frames-clip_hm5w.tgz
