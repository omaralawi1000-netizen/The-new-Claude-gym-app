# Gate report: pushdown

**RED: fix before any judge** (1 fail, 12 pass, 2 for a human eye)

- PASS  Pixel stage ran on every frame (holefill3 made all final frames): raw 130, final 130
- PASS  No diagnostic job crashed: none
- PASS  Hands on the prop (contact): inside 0, worst clearance 0.3 mm
- PASS  Rope strands run only toward the clip: 0 strand-frames
- PASS  Rope straight past the fist: 0 strand-frames
- FAIL  Far rope end held (nothing floating): 2 floating frames
- PASS  Cable clear of outlines: tangent runs 0, longest 0 px
- PASS  Fist tilt smooth (<= 0.15 deg/f^2): max 0.119
- PASS  Near fist clear of the machine: worst gap 230 px at f100
- INFO  Far-limb slivers (judge decides size): frames 75,76,9,104,10,13,73,74,39,98,102,103
- PASS  Background specks after the fill (speck2h): 0 frames
- INFO  Dimmed gap ends (check in sequence): frames 22,31,76,84,110
- PASS  No pops or flicker (clipcheck): []
- PASS  Motion smooth, no hitch (blurred steps): SMOOTH steps 130 median 0.497 max 1.435 | seam 0.085 vs neighbours 0.117 | spikes none
- PASS  Pixel scans saw every frame: speck2h 130 frames, clipcheck "frames N" ok

Logs and crops: this folder. Final frames: ../pushdown_final/
