# Judge verdict clip10-r14: FAIL (stills 8.6, motion 8.6 from stills only, rope 8.3). Overall 8.5

Main reason: the open gap at f44-68 is a clear improvement and reads natural. But the white dotted/checker fleck is now on the rope itself at the fist junction (f39-41 and f70-78), a pale blob shows at f80, and the dark fan behind the far elbow is smaller but still there (f16-22, f90-96).

## What I actually viewed (full-frame coords, 960x640, PIL crops)
- Upper-body sheet x1: f0, 24, 48, 66, 84, 110.
- Far fist sequence x4: f20-28 (two sheets).
- Wedge crops x5: f12, 14, 16, 18, 20, 22, 90, 93, 96, 100.
- Gap crops x7: f40, 44, 48, 52, 56, 60, 64, 68, 72, 74, 76, 80.
- Fleck crops x8: f37-41, 70-73, 76, 78, 80, 82, 84.
- NOT viewed: the other ~85 frames, mp4/webm (cannot play video), keys/ folder, gate crops. Motion is judged from consecutive-frame crops in the windows above only.

## Open-gap question (change 1)
- f44-68: the gap shows background in a clean triangle between rope and fist. It reads natural, like real air between a rope strand and a fist. No grey patch, no dotted outline in the gap itself. FIXED, and it is a real improvement.
- Open/close: f37-41 and f68-76 show no pop in the gap. It widens and narrows smoothly. No hole read.

## Far fist at f21-26 (gate RED item)
- Viewed f21-28 at x4. The far hand sits behind and under the near hand; the white clip/cap sits at the top of the strands, and the two hands read as stacked.
- It does not read as floating and does not flicker in the sequence. I judge the FARDIAG failure a false alarm for the eye.
- Caution: the gate stays red. Either relax the rule for f23-24 (far fist visible 135-148 vs 150) or note an override. Do not change the render for it.

## Problems
1. MUST-FIX: dotted/checker fleck on the rope at the near-fist junction. Seen at f40, f41, f70, f71, f72, f73, f78 as a small lattice of white pixels about 6x8 px at roughly (326-336,347-356). Single white speck at f76. It is the same spot as r13's dotted outline, now on the rope. A phone viewer sees it every rep at both ends of the hold (about 10 frames at each end).
   - Fix: in holefill3.py, do not paint or dim in the box (322-340,344-360) for f38-42 and f68-80. If the dots are the gap-end dimming (gate lists dimmed ends f22,31,76,84,110), turn that dimming off there. Otherwise clamp each pixel in that box to the median of its 3x3 neighbourhood, then re-view as an x8 strip.
2. MUST-FIX: pale grey blob at f80 on the rope between the near hand and the fingers, about 8x5 px at roughly (343-352,348-353) (the f80 crop). It is brighter than the rope and looks like a hole or a highlight. Also check f79 and f81. Fix: same as 1, or find the source with bgspeck.py / PICKDIAG at that pixel; if it is background showing through, dim to the local rope tone; if it is a specular, cut the highlight.
3. Far-elbow dark fan: smaller than r13 but still visible. A dark fan or shadow smear shows behind the far elbow, pointing down-right, at f16-22 (strongest f18-20) and f93, f96. f12, f14 and f100 are clean. About 10x14 px.
   - Fix: bend elbow_l further, to about -25 over f10-26 and f86-102, ramped over 20+ frames (rope tilt still <= 0.15 deg/f^2). Or pull that far-upper-arm/lat layer in with `UNDER_ARM_IN` 0.020 for the far side and name the mesh with PICKDIAG through (340,284) at f18.
4. Far strand vs near strand material (not changed, not rechecked closely): at f24 and f48 the far strand looks about as dark and as flat as before. Raise its base colour 8-10% and its bump to match the near strand. Nice to have next to 1 and 2, but a viewer may notice.
5. Nice-to-have: the knob is still a short dome cylinder.

## Far arm check (change 2)
- f0 and f110: far fist sits behind the near fist, no intersection. The far arm sits cleanly against the torso. Nothing broke. Rope tilt looks fine in f0, f24, f48, f66, f84, f110.
- Lockout (f66, f84): both arms straight and nothing floating. The rope hangs as a V from the thumb side and bends round at the fist. No stiff pole.

## Scores
Stills 8.6, motion 8.6 (stills only), rope 8.3. Overall 8.5. FAIL: pass needs 9+.

## Verdict
FAIL. The gap fix works. To pass: remove the dotted fleck and the f80 blob (one fix to the pixel stage in the same two windows), and hide the far-elbow fan (more elbow bend). Then re-look at x8 strips of f38-42, f68-82 and f16-22.
