# Judge verdict clip9-r13: FAIL (stills 8.4, motion 8.5 from stills only, rope 8.2)
Main reason: none of the three open items from r12 is actually fixed. The grey patch with a dotted white outline at the near fist/rope junction is still there (f44-f68), the dark far-forearm wedge is still there (f14-22, f90-96), and a pale fleck still shows at f72. The far strand is still darker and smoother than the near one. The automatic gate said GREEN, but it does not look at these.

## What I actually viewed
Final frames from /root/fig/ap/gate/pushdown_final (960x640), cropped and enlarged with PIL, then looked at as PNGs:
- f36 full frame.
- Wedge crops x5: f12,14,16,17,18,19,20,22 and f90,92,93,94,95,96,98,100.
- Fist/fleck crops x5: f32-37 and f56,58,59,60,61,62.
- Patch crops x8: f40,44,48,52,64,66,68,72.
- Rest-pose contact sheet x3 of the upper body: f0,24,48,66,84,110.
Not viewed: the other ~100 frames, the mp4/webm (cannot play video), the keys/ folder. Motion is judged from frame-to-frame crops only (f12-22, f32-37, f56-62, f90-100) and from the gate's numbers (clipcheck, step size, loop seam), which I did not re-run. Coordinates are full-frame 960x640.

## Previous open items
1. Far-forearm dark wedge: NOT FIXED. It is now a long dark streaked wedge poking out behind the far elbow/forearm, pointing down-right.
   - f14 starts small at about (330-350,274-282). f16-f19 it is at its worst, about (331-355,278-296), and looks like a hair or shadow smear.
   - It is still there at f20 and f22, where it reads as a dark fan above the forearm.
   - Second window: f90 about (330-352,276-288), f92 and f93 about (330-355,277-290), f94 and f95 smaller. f96 faint, f98+ clean.
   - The r13 tuck did not hide it. In f12 and f100 it is clean, so it appears and disappears within a few frames.
2. Flecks near the near-fist/rope junction: PARTLY FIXED, but the bigger problem is the patch below.
   - f33-36 are clean at x5, with no white dots. Good.
   - f58-62 still show the white dotted outline (see the new item below).
   - f72 shows a pale light-grey blob about 5x6 px at roughly (342-347,350-356), beside the fingers under the rope. It reads as a hole or highlight. Same spot as r12's f73 fleck.
3. Far strand flatter than the near strand: NOT FIXED. At lockout (f48, f66, f84) the near strand shows a clear twist lay in light grey. The far strand (the right-hand side of the V) is darker with a weaker lay. At x3 it reads as a second, darker material. The V is no longer flat, and the rope bends smoothly at the fist, which is good.

## Problems that are still open or new
- MUST-FIX: flat grey triangle with a dotted white outline at the near fist, f44-f68, strongest f52-f62. It is about 8x12 px at roughly (327-336,345-359), between the rope and the knuckles.
  - It has no texture and is a flat mid-grey. Its edge is a dotted line of white pixels, easy to see at f58-f62 and still visible at f48, f52, f64, f66 and f68.
  - This is exactly the "dotted shape" Omar bans. r13 did not change it. It is the filler (holefill3 or FIST_SEPTUM).
  - On a 120 Hz phone at DPR 3.75 it is about 30-45 device px, so a viewer will see it for about 25 frames every rep.
- Pale crumbs and halo along the far fingers and under the fist edge, f33-f40 and f68-f80, mild at x5. They hold shape fairly well from frame to frame. Nice-to-have.
- Knob is still a short cube/cylinder with a dome (f0, f24, f84, f110). Fine, but not Apple-level.

## What is good
- Lockout: both arms reach full extension at f66 and f84, with no bend left and nothing floating. The near fist at lockout is clean.
- The rope hangs from the thumb side and bends in a round curve at the fist (f24, f36, f48, f66). The V is a proper hanging V and not flat. The cable is a straight line from the clip. No stiff pole.
- Glow on the triceps is strong and even. No pink slivers in the viewed crops. Anatomy and muscle texture are clean.
- Far fist at the top (f0, f110) sits behind the near fist with no intersection.
- Frame-to-frame in the viewed windows: no pops. The gate's seam and step numbers are good. I did not play the video.

## Scores
Stills 8.4, motion 8.5 (stills only), rope 8.2. Overall 8.4. FAIL: pass needs 9+.

## MUST-FIX with exact fixes
1. f44-f68 patch at (327-336,345-359).
   - Cause: the fill is flat-coloured and has a high-contrast edge.
   - Fix A (best): remove the 2-D fill for this box. Instead place a real hidden-surface filler in 3-D (a dark rope-tone tube or palm disc that closes the gap between rope and knuckles, matte charcoal like the rope, with the rope's bump) so it renders with the same lighting.
   - Fix B (fallback): keep the 2-D paint-in, but sample the colour from the pixels 3 px outside the blob and add a 2-3 px feathered edge. Add the rope's grain noise (about +-6 levels). Make sure no pixel in the fill edge ring is brighter than its neighbours (clamp to the local median).
   - Fix C: dim only the brightest edge pixels to the surrounding median, and fade the fill in and out over 8 frames, not 3.
   - After the fix, re-look at f44-f68 as an x8 strip. There must be no dotted line at all.
2. Wedge, f14-f22 and f90-f96 at (330-355,274-296).
   - Option 1: lighten and shorten it by moving the far arm. Put the far elbow 15-20 mm further in toward the ribs (`elbow_l`) over f10-f24 and f86-f100, ramped over 20 or more frames so rope tilt stays <= 0.15 deg/f^2.
   - Option 2: hide it. The dark streak is the far upper-arm or lat layer showing past the near forearm. Pull that layer in about 15 mm with the `UNDER_ARM_IN` method, and add it to the PICKDIAG list for a ray test through (340,284) at f17 to name the mesh.
   - Option 3: make the streak skin-toned and soft. This is a hack. Option 1 or 2 is better.
   - Add f10-f24 and f86-f100 to the gate's wedge box. The gate missed these frames again.
3. f72 pale blob at (342-347,350-356) and the old fleck frames f71-f73. Check with `bgspeck.py` / `POCKETDIAG` whether it is background. If it is, dim it as a gap end. If it is a lit highlight on the rope, shrink the highlight.
4. Far strand. Raise the far strand's base colour about 8-10% and its bump strength to match the near strand, and set the strands' shared material and bump scale to the same value (three-strand lay pitch 25 mm). At lockout both strands must show the lay at x3.

## Nice-to-have
Pale crumbs around the far fingers f33-f40 and f68-f80 (soften edge, same fix as 1B). Knob shape.

## Verdict: FAIL (8.4). It will pass when the dotted patch is gone (one fix) and the wedge is hidden. Both are the only things a viewer would catch on the phone.
