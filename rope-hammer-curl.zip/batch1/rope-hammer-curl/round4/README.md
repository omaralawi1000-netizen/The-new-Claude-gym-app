# Rope Hammer Curl, round 4 (fixes for judge round 3)

Round 3 files are in `round3/`, and the verdict is `judge-verdict-r3.md`. The code is in `../code-r4/`. Settings are in `rope10.sh` (contact, framing, keys and close-ups).

## Flaw 1: taut strands
- **Strand shape:** the heel handle now scales with the turn: `HEEL x cos(phi/2) x min(1, D/0.15)`. The fan is 0.15.
- **Strand length:** 0.33 m (was 0.27), shared with the pushdown, where 0.27 put the clip level with the fists at lockout.
- **`ROPEMONO`:** a new check in `GRIPDIAG`. It projects each strand from the fist exit to the clip onto the clip-to-pulley line and fails on any back-step over 1 mm.
  - Result over the same 44 frames: **0 violations**, worst back-step 0.3 mm (`contact-log.txt`).
- **Contact got worse first, as you predicted.** With the shorter heel and the 12 mm in-fist bend, the rope cut into the hypothenar on the bottom frames (f0-15 and f110-125, up to 68 points, 2.6 mm deep).
  - **Fix:** in-fist bend `ROPE_INSET` 12 → 6 mm, and fist tilt up to **14°** at phi 85° and above (was 8°). 8° still left a 2.0 mm back-step at f0. 12° left 0.9 mm, and 16° left 0.0 mm.
  - 14° is ulnar deviation of the wrist toward the rope line, well inside the normal range (about 30°).
  - **Final, 44 frames:** **0** hand-skin points inside the rope, worst clearance 0.3 mm. Rope against body or head: 0 crossings, min clearance 2.1 mm (left strand against the flexor digitorum superficialis). Rope to head is at least 176 mm.
- **Tilt over the rep** (ROPETILT lines): -14° from f0 to f20, then a smooth climb through 0 at about f38 to +5.1° at the top (f60-64), and back.
  - **Flagged for the clip:** the ramp starts at a corner at phi 85° (about f21). I'll smooth that corner before rendering the clip and re-run the contact check then.
- **What you see:** `rope-x4-f000-f030-f055.png`. There's no belly under the far fist at f30 and no ear at f55. The far strand wraps the pinky edge and runs straight to the sleeve.

## Flaw 2: pink forearm
- **Fix:** `FORE_NOLIGHT=1` is in every rope script.
- **Check:** `forearm-x6-f030.png` (native x6). The forearm under the near biceps is clay grey.

## Flaw 3: pulley
- **Changes:** darker rim rings on both wheel faces, and the cable on the rim (`ROPE_RG` 1 mm), wrapping under the wheel into the carriage.
- **Honest note:** from this camera the wheel face hides the groove. At x4 (`pulley-4x-f030.png`) the cable still reads as reaching the rim on the left, and the wrap is barely visible. The rim ring is faint. At app size it reads as a wheel with a cable.
- **Optional item:** the carriage block now sits close to the base plate.

## Flaw 4: composition
- **Fix:** `CAM_PAN=0.43` (the camera and its target slide sideways).
- **Result** (`framing-log.txt`, `CAMDIAG` on all 130 frames): the figure-plus-station midpoint is -2..+1 px from x = 480 on every frame. Lens 43 is kept.
- **Margins:** base 25 px (was 22), top 45 px.

## Flaw 5: the grey notch in the biceps glow (f55)
- **Cause** (`PICKDIAG`, a ray through each pixel): the clay under-layer of the upper arm (`U:arm region`) poked out 4-5 mm in front of the biceps and brachialis at full flexion.
- **First try failed:** a Displace along normals inflated the layer, because it is two overlapping sheets with opposite normals.
- **Fix:** `UNDER_ARM_IN=0.014` pulls the layer up to 14 mm toward the humerus axis, in the rest pose, over the upper arm only, eased at both ends.
  - 6 mm still left a small tick at f0/f30/f55. At 14 mm there are no holes anywhere on the arm at f0/f30/f55.
- **Proof:**
  - `biceps-notch-x6-f055-r3-vs-r4.png`: round 3 against round 4.
  - `biceps-x8-f055-f030.png`: native x8. The belly edge is clean.

## Flaw 6: f0 near cap
- **Result:** with the shorter heel and 14° of tilt, the strand leaves under the near fist and the cap tilts up off the strand line (`rope-x4`, first panel). There was no extra pronation.

## Files
- `hammer-keys.jpg` (f0/f30/f55), `hammer-f000/030/055.png` and `hammer-keys-appsize.jpg`.
- `hammer-hands-closeups.jpg`: both hands, clip side and from below, at f0/30/55/70.
- `rope-x4-f000-f030-f055.png`, `biceps-*`, `forearm-x6-f030.png` and `pulley-4x-f030.png`.
- `contact-log.txt` and `framing-log.txt`.

No clip yet.
