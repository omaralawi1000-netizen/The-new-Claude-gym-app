FAIL. Score: 8.7 / 10.

# Rope Hammer Curl, clip 1: judge verdict (judge round 6)

The clip is close. The motion is smooth, the loop seam is clean, the rope stays in the fists, and the glow and the red hold up.
The new farthest-root rope solve is physically better than the stills I passed: a longer, straighter V with no wrap under the
near fist. It does **not** send the rope toward the face. Rope-to-head is at least 103 mm and the strands never cross the head in projection.

It fails on one thing, the condition I set in round 5 (nice-to-have 1: "if the clip shows it touching on f50-65, fix it").
**For about 25 frames at the top of every rep (f46-70, 0.8 s), the near end cap sits right on the trapezius/neck silhouette.**
The background gap between the cap's top edge and the shoulder outline is 0-3 px. It slides along that edge as the fist creeps.
In the round-5 still the cap sat inside the neck outline and clearly read as in front of him. In the clip it sits on the outline,
so at 1x it reads as the rope end resting on, or pressing into, his shoulder at the base of the neck. That happens at the hold,
where the eye stops. On Omar's screen it's the first thing you see at the top of the rep.

## What I looked at myself
- **Every frame, extracted** from `hammer-clip-1.mp4` (130 frames) and `.webm` (130), plus the lossless keys `clip-f000/030/055.png`, `stills-r5-vs-clip-f030-f055.png`, `clip-every-10th-frame.png`, and the round-5 `hammer-f030/055.png`.
- **My crops (in this folder):**
  - `judge-r6-cap-collarbone-f055-r5-vs-clip-x7.png`: the near cap at f55, round 5 against the clip, x7.
  - `judge-r6-cap-trap-f44-71-x6.png`: every frame from f44 to f71, the cap against the shoulder outline, x6.
  - `judge-r6-forearm-f055-r5-vs-clip-x8.png`: the f55 near forearm, x8.
  - `judge-r6-hammer-hands-seam-f118-6-x4.png`: both hands across the loop seam (f118-129, f0-4), x4.
  - `judge-r6-hammer-hands-f20-46-x3.png`: the up-swing, every 2nd frame, x3.
  - `judge-r6-hammer-glow-elbow-keys-x5.png`: the biceps/brachialis glow edge and the elbow at f0/30/55, x5.
  - `judge-r6-hammer-far-forearm-speck-f37-38-80-81-x8.png`: the pink speck (see nice-to-have 1).
- **Pixel row dump** of the f55 key across the cap (rows 124-139, x 350-379): at row 129 there are 2-3 background pixels (211-233) between the body (75-105) and the cap. By row 130 they merge. That's a tangent, not a clear overlap and not a clear gap.

## Item by item

| Check | Finding | Verdict |
|---|---|---|
| New rope path (longer V, straighter strands) | The strands run straight from the fist edge to the clip on every frame I looked at. No wrap, no kink except the 32 mm exit arc. The near strand passes in front of the far forearm at f38-44 and reads as in front. Nothing heads toward the face: the cap stays at the shoulder line, about 20-25 px below the jaw in the image, and never overlaps the head or neck in projection. | **Natural. Better than r5.** |
| Rope near the neck and collarbone | The near cap is tangent to the trapezius outline on f46-70 (crop `judge-r6-cap-trap-f44-71-x6.png`). | **Must-fix 1.** |
| f55 forearm box +6.9 | My R-G row map of the key PNG: rows 180-189 are +5..+32. All of it sits in the left 4-9 columns on a diagonal, which is the biceps glow edge and its halo, not the forearm. Rows 190-214 average -1.5..+3.6. A faint 1 px crevice line runs through rows 196-214 (+5..+14). It's the same line, at the same strength, as in the round-5 still I passed (+10..+16 there). In the x8 crop the forearm is clay. | **Claim confirmed: halo, not a forearm problem.** |
| Hands on the rope | The fingers wrap the rope on every frame in my sheets. The cap stays above the near fist, and the far strand exits from the same place. I saw no slide or pop of the rope in the fist from frame to frame. The rope is not a rigid prop, but the grip point doesn't creep either. | **Pass.** |
| Loop seam | Whole-frame mean change at 129→0 is 0.36, against 0.10 and 0.18 either side. But on a blurred 8x8 block measure the seam step is 0.119 mean / 7.0 max, against 9.2 and 12.7 for its neighbours. The raw diff map lights every edge in the frame equally, the feet and the station included. That is the encoder's keyframe, not motion. The webm has the same thing at 127→128. Visually f128 → f0 → f2 continues smoothly. | **Pass.** (The thread's "0.134" is the static-area number, not the whole frame.) |
| Pops and jitter | No step stands out in either the raw or the blurred per-step change. The motion eases into the top (f56-62) and the bottom (f123-128) with no hard stop. | **Pass.** |
| Glow edges | Anti-aliased, with no stair steps at x5. The brachialis lobe reads apart from the biceps at f30 and f55. | **Pass.** |
| Elbow under-layer speck | None at f0, f30 or f55 at x5. | **Pass.** |
| Pink speck scan, every frame | Isolated R-G > 22 pixels away from the glow: at (288-290, 180-186) on f41-44, f54-57 and f82-90 this is the glow halo on the deltoid, which is fine. At (420-428, 198-208) on **f37-40 and f80-81** there is a 3x2 px desaturated pink blob on the far forearm, just right of the near fingers. It's the far brachioradialis being covered by the near fist. That is the mover, but at 1-2 px chroma it shows pink, not red. | **Nice-to-have 1.** |
| Red | Crude core median (R-G > 140) on the mp4: hammer 228-229/60-61/44-45 and curl r18 230/59/41, 223/52/38. Within 4 of the curl's f30 key. | **Pass.** |
| Logs | I parsed them myself. `contact-log.txt`: 130 EZGRIP lines, 0 inside, ROPEMONO 0.6 mm, rope-to-head min 103 mm. `tilt-log.txt`: 130 frames per side, max 0.110/0.106, no identical runs. | **Matches the README.** |

## Must-fixes
1. **Near end cap tangent to the shoulder/neck silhouette, f46-70** (native about 365-380 x 125-135).
   - **Pass:** on every frame from f40 to f75, the cap either overlaps clearly inside the outline (at least 4 px of body above its top edge, as in the r5 still) or stands clear of it (at least 6 px of background, the CABLEDIAG mark).
   - **Fix options, cheapest first:**
     - Lower the near `shoulder` flexion at the top by 0.3-0.5 deg, or add about 1 deg of near `abduct` at the top. Either moves the fist and cap down and out, so the cap drops inside the pec/deltoid area.
     - Or give the near fist a few more degrees of supination at the top, so the cap tips forward of the neck line.
   - Re-check `ROPEMONO` and the rope-to-body distance after the change, then re-render the clip.

## Nice-to-haves
1. **Pink speck on the far forearm at f37-40 and f80-81**, about 3x2 px, beside the near fingers. It twinkles once on the way up and once on the way down. If it's cheap: let the near fist cover the far brachioradialis sliver a frame sooner, or cut its glow where the visible run is under 4 px. It doesn't block on its own.
2. **Contact minimum 2.1 mm** (the far strand against the far forearm flexors, f0). Clean in the pixels. Note it if the near-arm change moves things.

## Taken from the thread, not re-run (no Blender in my container)
- The GRIPDIAG/TILTDIAG/CAMDIAG numbers. I parsed the logs, but couldn't regenerate them.
- PICKDIAG: that rows 180-189 of the f55 box are the "body under-layer" halo. My pixels agree with it.
- That the farthest-root solve is the physically correct taut position. It looks right; I didn't re-derive it.

## Can it ship?
**Not yet.** Fix the cap tangent, re-render the clip, and send f40-75 at x6 alongside it. Everything else on this clip is at or above the curl's 9.0.
If the cap reads clearly in front, or clearly clear, on those frames, I expect this clip to pass.
