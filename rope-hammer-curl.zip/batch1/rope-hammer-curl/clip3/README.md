**APPROVED by Omar 25 Oct 09:36 ("Hammer looks good"). Locked copy: `approved/` (mp4, webm, keys, all 130 lossless frames, checksums). Do not change it; any new work goes in a new clip folder.**

# Rope Hammer Curl, clip 3 (rope realism, after Omar's "that's not how a rope works")

Clip: `hammer-clip-3.mp4` / `.webm` (130 frames, 30 fps, 4.3 s loop, 960x640). Code: `../../code-r8/` (`rope39.sh` + `rope40.sh` render it, `pinholes.sh` is the pinhole pass).
Everything below is self-checked, not judged.

## Why it changed (Omar, 20 Oct, 3 real videos: `/mnt/project-files/.notes/inputs.md`)
- **Clip 2:** the pulley sat 70 cm in front and the fists hip-width apart, so the rope stuck out forward and flat like a stiff bar.
- **Real lifters** (all 3 videos) stand at the low pulley with the fists close together in front of the thighs. The rope hangs straight down from the fists (knobs on the thumb side) into a near-vertical cable.
- **Clip 3:**
  - The pulley wheel sits 22 cm past the toes (`LOW_Y 0.36`) on a short floor arm.
  - The column stays 72 cm out (`COL_LOW_Y 0.72`), so it is never behind the fists. At 45 cm it sat right behind them on the lift.
  - At the bottom the arms come in toward the midline (`abduct -9`) with the upper arm a touch forward (`shoulder 12`) to clear the thighs.
  - The top is unchanged (shoulder -5, twist 70, abduct about 2).
- **Sheet:** `real-vs-clip2-vs-clip3.jpg`, real bottom/top against the clip 2 and clip 3 bottom/top.
- **Rules:** see "Rope realism rules" in `figure-rules.md`. Please compare side views against the real reference.

## Far arm (pink speck rule)
- **Specks found:** with the fists close, SLIVERDIAG found 1-3 px red specks of the far forearm between the near fingers and the rope (f41, 48-49, 73-76, 81, 84-85).
- **Fix:** the far elbow now runs 4 deg ahead, held f40-75 (`elbow_l`, ramp f20-40, back by f92).
- **Left** (`far-forearm-sliver-log.txt`, `far-forearm-under-near-cap-x6.png`):
  - a 0.2 px piece at f46 (invisible);
  - a 1.5 px grey piece at f39, not red;
  - at f35-37, a 1-2 px red stripe of the far brachioradialis along the top of the near fist, 14-24 px long (the judge called the clip 2 equivalent cosmetic);
  - f85-86, 16-31 px of the far brachioradialis in the window under the near cap (red, like clip 2's f84-86).

## Background pinholes by the hands (judge r7's brightness test, every frame)
- **Test:** `speck2h.py`, 8-connected luma > 200, at most 16 px, a dark pixel within 2 px, box 300-500 x 100-420.
- **Raw render:** 26 frames flagged.
- **Ray check:** I ray-cast every frame (`POCKETDIAG`, 2x2 rays per pixel, masks saved). The flagged spots are real background seen through:
  - a tick between the near index finger and the rope neck through the whole bottom (f0-18, f104-129, 1-4 px, up to 215);
  - the closing ends of 5 gaps that open and close as the hands travel:
    - thumb vs forearm, f13-14 / f109-110;
    - near wrist vs far forearm, f26-31 / f92-93;
    - cap neck vs chest, f38-39 / f81-83.
- **Geometry first:** the wrist and fist fillers (`FIST_SEPTUM` / `WRIST_CORE`) changed nothing, because these are open gaps, not tunnels through the hand.
- **2-D pass, please look** (`holefill3.py` then `holefill2.py`; logs `holefill3-log.txt`, `holefill2-log.txt`; sheet `pinholes-raw-vs-final-x3.png`):
  - **Closed pockets** that never join a bigger gap (the rope-neck tick, a dot by the far fingers) are painted in from their rim, then smoothed. This holds on every frame they appear, so nothing flickers.
  - **The last 1-3 frames of a gap that closes** (or the first frames of one that opens) are only dimmed 60 % toward the fill. Filling them fully would make a visible gap pop out a frame early. Dimmed, the gap fades as it shrinks.
  - **Four small notches** open to the background (f30, f48, f92, f97) get the bounded fill.
  - No other pixel changes.
- **Final:** the luma > 200 test gives 0 frames (raw: 26). Against the ray masks, light spots that are background (luma > 160) went from 49 frames to 7. Those 7 are the dimmed gap ends, now 162-191: f13, f26, f38-39, f81-82 and f110. Raw vs final is in `pinhole-scan-raw.txt` / `pinhole-scan-final.txt`.

## Near end cap (`cap-log.txt`, CAPDIAG f25-95; sheet `cap-transit-f25-95-x3.png`)
- **Inside the chest outline:** f47-72, with 5.0-7.2 px margin. f73 has 4.2 px and f76 2.0 px.
- **Please look:** the cap crosses the torso side outline on the lift (f25-46) and on the lowering (f77-95).
  - Now that the fists stay in front of the body, the cap starts inside the body outline at the bottom.
  - It passes over background while the forearms are level (up to 233 px of the cap over background), then comes back inside.
  - So the crossing is longer than clip 2's f40-44, but it is one smooth pass each way. The cap never rests on the outline.

## Other checks
- **Far end (`far-end-log.txt`, FARDIAG every frame):** 0 floating frames.
- **Contact (`contact-log.txt`, all 130 frames):**
  - hands: 0 hand-skin points inside the rope, worst clearance 0.3 mm;
  - rope shape: ROPESTRAIGHT 0.00 mm, ROPEMONO 0.0 mm;
  - rope vs body: 0 crossings, at least 2.1 mm, at the near strand vs the far forearm flexors.
  - The log was taken on the f40-75 far-elbow version for f20-92 and on the first version for the other frames, which are the same pose.
- **Cable (`cable-log.txt`, CABLEDIAG):** 0 tangent runs. The cable now runs almost vertically to the floor arm.
- **Tilt (`tilt-log.txt`):** max |2nd diff| 0.121 (r) / 0.124 (l) deg/f², pass 0.15. Tilt is 0 by design f25-97.
- **Motion (`clipcheck.txt`):** no spikes; loop seam 0.141 against a per-step median of 0.470.
- **Colour (`colour-log.txt`):** red core 220-223/47-49/31-32, lightness 0.552-0.557 (clip 2 0.550-0.552).

## Files
- `hammer-clip-3.mp4`/`.webm`, `clip-f000/030/055.png`, `clip-every-10th-frame.png`.
- Sheets: `real-vs-clip2-vs-clip3.jpg`, `pinholes-raw-vs-final-x3.png`, `cap-transit-f25-95-x3.png`, `far-forearm-under-near-cap-x6.png`.
- Logs: `cap-log.txt`, `far-forearm-sliver-log.txt`, `far-end-log.txt`, `contact-log.txt`, `cable-log.txt`, `tilt-log.txt`, `clipcheck.txt`, `colour-log.txt`, `holefill3-log.txt`, `holefill2-log.txt`, `pinhole-scan-raw.txt`, `pinhole-scan-final.txt`.

## After the judge (25 Oct): two nice-to-haves fixed, SELF-CHECKED only (not re-judged)
Judge round 8 passed this clip at 9.2/10 (`judge-verdict.md`). The judged files are kept in `judged-version/`. The clip in this
folder now carries two of the judge's nice-to-haves:
1. **Rope bend at the fist (bottom, f0-24 and f100-129):** the fists tilt further into the rope line (max 26 deg, was 14) and a
   sharp turn wraps tighter round the heel of the hand (32 -> 14 mm). The turn at the fist edge drops from 73 to 56 deg at the
   bottom, so the strand no longer runs 1-2 rope widths sideways before it heads to the clip. The top (turn <= 35 deg) is unchanged.
2. **Return cable:** the wheel now sits on a low floor arm and the cable runs along the top of that arm into the housing (it used
   to cross open air into the side of the block).
Self-checks on all 130 frames: grip contact 0 inside (worst clearance 0.3 mm), ROPEMONO 0, ROPESTRAIGHT 0, far fist 0 floating,
cable 0 tangent runs, final pinhole scan 0 (`pinhole-scan-final.txt`), dimmed gap ends the same kind the judge accepted (thumb
wedge now f10-11 / f112-113). Code: `../../code-r8/rope41.sh`.
