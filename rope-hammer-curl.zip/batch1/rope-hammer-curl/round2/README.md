# Rope Hammer Curl: round 2 stills (re-judge)

The round 1 files and the round 1 verdict are in `round1/`, and the older first pass is in `round1/first-pass/`.

## Files
- `hammer-keys.jpg`: f0 (bottom), f30 (mid lift), f55 (top). `hammer-keys-appsize.jpg` is the same at about app size.
- `hammer-f000/030/055.png`: full size (960x640, 16 spp, glow on).
- `hammer-hands-closeups.jpg`: columns are f0, f30, f55 and f70. Rows, top to bottom:
  - right hand, clip-side view;
  - right hand, from below;
  - left hand, clip-side view;
  - left hand, from below.
- `rope-material-ab.jpg`: f30 at 2x.
  - A is round 1 (clay tube, 0.38 m strands).
  - B is round 2 (charcoal braid, rubber stoppers, 0.27 m strands).
  - The other round 2 changes also differ between A and B (a lower top, a split, the wrist), because A is the round 1 render.
- `contact-log.txt`: 44 frames, every 5th from 0 to 125 plus every frame from 48 to 70.
- `hammer.py` (choreography), `props.py` and `render8.py` (build).

## Round 1 items and what changed
1. **The rope read as a pipe.**
   - The rope is now its own charcoal material with a three-strand helix bump (25 mm pitch), fine fibres and darker grooves.
   - The stoppers are matte black rubber. Red is still the only colour.
   - Wrap radius: `min(0.032, 0.45*|C-E|)`, up from 0.017.
   - Above 45°, the exit moves inside the hand span, by up to 20 mm at 90° and beyond.
     - The f0 hairpin is gone. The measured phi at f0 is about 100°, not 150°.
     - I tried a 28 mm inset or more: it puts hand skin inside the rope (7-66 points), so 20 mm is the limit.
2. **Stoppers.** Each stopper is a rounded cylinder: 44 mm long, 21 mm radius, a 6 mm chamfer where the rope enters, a straight body and a domed end. There is no neck and no flat cap.
3. **Contact test, rewritten.** All parts are now tested against what renders.
   - The rope centreline is sampled every 5 mm: the strands, the stoppers (with their radius), the clip (14.5 mm) and the cable (3 mm).
   - It is checked by unsigned distance against ALL visible MUS, SKIN and UNDER meshes, plus a ray-cast crossing test, and against EggHead.
   - Samples within 75 mm of their own hand skip only that hand's SKIN and UNDER, which is the in-fist segment.
   - Hand-vs-rope now also tests the same-side forearm MUS within 4 cm.
   - Sentinels print as ">200mm", ">30mm" and ">300mm".
4. **Top (f55).**
   - Elbow peak lowered to 118° (the table scaled), and shoulder flexion at the top lowered to 8.2°.
   - Split: `abduct` goes 2.0 → 6.0 at f55 → 6.8 at f66 (a creep, not a hold) → 2.0 by f100.
   - The rope's closest point to the head (EggHead) is **176 mm**, over the whole clip.
5. **Coracobrachialis glow.** The regex is anchored. Objects that glow (printed at build):
   - Long head of biceps brachii .l/.r
   - Short head of biceps brachii .l/.r
   - Brachialis muscle .l/.r
   - Brachioradialis muscle .l/.r
6. **Wrist.** 0-3° flexion, down from 4-12°.
7. **Brachioradialis band.** Lit from u 0 to about 0.55 along elbow→wrist, fading after that. The distal tendon stays grey.
8. **Station.**
   - The station recedes: its own light, low-contrast matte material.
   - The low pulley is a grooved 63 mm wheel (1.5x) with a hub, cheek plates and nuts on a carriage.
   - The clip is a steel sleeve with an eye ring. The cable is its own dark material and runs into the wheel groove.
9. **Strands.** 0.27 m from the exit to the clip, a standard 27-inch rope (rules updated in figure-rules.md).

## Contact test (contact-log.txt)
- Hand skin and same-side forearm muscle inside the rope: **0 on all 44 frames**. Worst clearance +0.3 mm.
- Rope centreline vs all visible body meshes: min clearance **+2.1 mm**. That is against the flexor digitorum superficialis tendons at the wrist, beyond the rope's radius. There are **0 crossings**.
- Rope to head: **176 mm or more**.
- Hand skin to trunk and legs: **more than 30 mm** on every frame.

## Known, for the judge to rule on
- **f30, near hand:** the strand leaves the bottom of the fist straight down for a few cm before it turns toward the clip. From this camera the near half can read slightly squared. The wrap radius is limited by the 20 mm inset above, which is where skin starts entering the rope.
- **f55:** the near stopper sits in front of the chin and neck in screen space. In 3D it is 176 mm or more from the head, so this is overlap from this camera, not contact.
- The wrist-skin edge still shows in the close-ups from below, the same accepted limit as r15.
- The station is still a plain column. The low pulley is in frame, and the cable visibly runs into the wheel.
