# Rope Hammer Curl (batch 1, round 2): judge verdict

**Verdict: FIX. Do not render the clip yet.**

The body work from round 1 is done properly: glow, wrist, top of the rep, split, strand length and a contact test that is real now. The prop still fails, though, and now in a new way. The rope is charcoal, so it stands out more, but its shape is a **rigid squared bracket** with right-angle corners at the fists. Up close the "braid" reads as **ribbed corrugated hose**, not a laid rope. At app size, rope plus clip reads as a dark metal Π-handle, not a rope. The barbell in r15/r16 looks like a product shot, and this does not yet. The stoppers are now well made but are close to a microphone or massage-wand silhouette, and Omar will notice that. The pulley is built but hidden behind its own cheek plate.

What I looked at:
- README, round1/judge-verdict.md and figure-rules.md.
- hammer-keys, hammer-keys-appsize, rope-material-ab, all 16 close-up panels, f000/030/055 at native size, and 4x crops of both hands at f0/f30/f55 and of the pulley at f30/f55.
- r16 barbell f30 (pulled from curl-clip-r16.mp4) for the quality bar and framing.
- Code: props.py (rope_geometry, rope_mats, stoppers), render8.py (GLOW_RE, glow band, rope contact test), hammer.py.
- contact-log.txt: all 44 frames.
- There is no Blender here, so I could not re-run the numbers.

---

## Round-1 items, one by one

| # | Round-1 item | Claimed | What I found | Fixed? |
|---|---|---|---|---|
| 1 | The rope reads as a pipe | Charcoal braid, rubber, wrap 32 mm, inset, f0 hairpin gone | **Material:** done (charcoal, matte, rubber stoppers, red still the only colour). **Braid:** present in the shader, but the pitch is wrong (see Fix 1). Up close it reads as horizontal rings (corrugated hose). At 960 and app size it does not show at all, so the rope is a flat dark tube. **f0 near hairpin:** gone, which is true. **f0 far-hand Z-kink** (named in round 1): **still there.** In the f0 4x crop the far strand runs sideways, kinks down and kinks again into the clip. **Shape:** new squared corners at f30 (near) and f55 (far). | **NO.** It no longer reads as clay pipe. It now reads as dark bent bar or hose. |
| 2 | Pawn-shaped stoppers | Rounded cylinder 44 x r21, chamfer, dome | Built exactly as described (props.py:333-339). No neck bulb and no flat cap. | **Yes, to spec.** It brings a new silhouette problem (Fix 3). |
| 3 | Contact test not real | Unsigned centreline distance vs MUS/SKIN/UNDER/EggHead, crossings, f48-70 every frame | The code at render8.py:296-345 does what the README says. The log has f0-45 every 5th frame, **every frame f48-70**, then f75-125, which is 44 frames. 0 inside, 0 crossings, rope to head 176 mm minimum. Sentinels are fixed. The in-fist segment is still true by construction, as before, and is accepted. | **Yes.** |
| 4 | Top: stopper on the jaw, no split | Elbow 118, shoulder 8.2, abduct 2→6→6.8→2 | Verified in hammer.py. At f55 the fists finish at the front of the shoulders and the V opens. The near stopper now sits in front of the neck at collar level, not on the jaw. It still touches the neck contour in screen space, but at app size it reads like r15's bar at the chin. | **Yes.** I accept the screen-space overlap. |
| 5 | Coracobrachialis glow | Anchored regex | render8.py:54 is anchored, and the log prints exactly 8 GLOWS objects (biceps L/S, brachialis, brachioradialis), with no coracobrachialis. | **Yes.** |
| 6 | Wrist 4-12° | 0-3° | The table in hammer.py runs 0.0-3.0. The fists no longer fold toward each other, and the wrists read straight at every key. | **Yes.** |
| 7 | Brachioradialis weak | Band u 0-0.55 | render8.py:63 maps u 0..0.55. At f30 the near forearm is red to about mid-forearm, with the distal tendon grey. At f0 the far forearm reads as well. | **Yes.** |
| 8 | Station dominates; pulley does not read; no clip eye | Recedes; 63 mm grooved wheel + cheek plates; steel sleeve + eye | The column recedes, which is fixed. The clip sleeve and eye are present and read. **The pulley does not read:** from this camera the camera-side cheek plate covers most of the wheel. You see a grey box with a half-disc peeking out on the left, and the cable lands on the top edge of the carriage. The README says "the cable visibly runs into the wheel". **That is not true in these stills** (4x crops at f30 and f55). The wheel's bottom and the base also sit on the bottom frame edge. | **Partly.** The column is fixed; the pulley is not. |
| 9 | Strand 0.38 m | 0.27 m | props.py:229 is 0.27, and the rules are updated. The V is no longer tall. | **Yes.** |

---

## Fresh judgement

- **Rope look:**
  - **FAIL.** In the close-ups the grooves run nearly perpendicular to the axis: a vacuum hose or flex conduit, not a three-strand rope.
  - Cause, props.py:306-308: `PITCH = 0.025` is used as **one full turn per strand per 25 mm**. On a 27 mm rope (85 mm around) that is a lay angle of about 74° from the axis, which makes rings. A real three-strand rope has a lay length of about 3-3.5 rope diameters (about 85-95 mm per strand turn), with crowns about 30 mm apart at about 35-40°.
  - At 960 the bump is invisible, so it is a flat dark tube.
- **How the rope hugs the fists:**
  - **FAIL.** The path is straight through the fist, then a single circular arc, then a dead-straight line to the clip (props.py:270-283).
  - With phi near 90-100°, that gives an elbow-pipe corner under each fist: f30 near hand, the corner the README already admits; f55 far hand, a right-angle corner at the heel; f0 far hand, the Z-kink.
  - From the clip camera, the two strands plus the sleeve form a squared Π bracket. A taut rope reads as two clean, slightly curved lines that fan out of the sleeve and roll over the heel of each fist.
- **Rubber ends:**
  - Well made, but the silhouette is a full hemispherical dome (r 21) on a short 6 mm chamfer over a thinner rope.
  - In the close-ups (rows 1-4, every column) this reads as a microphone or massage-wand head.
  - Real triceps-rope end caps are a cylinder with a longer taper and a flatter, filleted end.
- **Grip:**
  - **PASS.** I checked all 16 panels: no rope through skin or fingers.
  - The fingers close round the rope and the thumb side carries the stopper.
  - The log agrees: 0 inside, worst 0.3 mm, and same-side forearm muscle included.
- **Joints and wrists:**
  - **PASS.** The wrists are straight, the forearm twist is clean, and the elbows are pinned through the lift.
  - The wrist-skin edge and tendon gaps show only in the close-up cameras (from below, and also at f55/f70 from the clip side). It is not visible at 960. This is the same accepted limit as r15.
- **Camera framing:**
  - Acceptable overall: the figure is centred like r16, the column stands to his right, and he has headroom.
  - One defect: the low pulley and base sit on the bottom frame edge, the wheel's bottom kisses it, and the base plate is cut. That is an awkward tangency in the one place the cable needs to read.
- **Premium at app size:**
  - **NO.** In hammer-keys-appsize the body and glow are premium.
  - The prop is the darkest, hardest-edged shape on the page, and it reads as a black metal bracket hanging off a grey box.

---

## Fixes (in order)

1. **Braid that reads as rope.**
   - Set the strand lay length to about 0.09 m. In the shader that means `PITCH = 0.09`, which keeps three crowns at about 30 mm spacing and a lay angle of about 35-40°.
   - Raise the groove contrast until the twist is visible on the **native 960 frame** at the near fist, not only in close-ups. Try a darker groove multiply and a bump distance of about 2 mm.
   - Ship a 960-native A/B crop (not 2x) of the near fist at f30.
2. **The strand shape must read as a taut rope, not a bent bar.**
   - **(a)** Let each fist tilt into its rope line: up to 8-10° of ulnar deviation, scaled by phi, so phi drops well under 90°. Round 1 offered this as an alternative, and it was never tried.
   - **(b)** Replace the arc plus straight line with one smooth curve, for example a cubic Hermite or Bezier. It starts at the inset exit E on the grip-axis tangent and ends at the clip along that strand's approach to the sleeve. Spread the bend so the maximum curvature sits at the heel of the hand and the rest is a long, gentle line, with **no visible straight drop below the fist and no corner**.
   - **(c)** Fan both strands into the sleeve tangent to the cable direction, not as a hard V.
   - **(d)** Kill the f0 far-hand Z-kink.
   - Re-run the contact test, since the heel is where the rope can catch the hypothenar.
3. **Stopper silhouette.**
   - Keep r21 and the black rubber.
   - Lengthen the rope-entry taper to about 12-15 mm, a cone, not a 6 mm shoulder.
   - Replace the hemispherical end with a flat end that has a 6-8 mm fillet.
   - Total length about 48-50 mm.
   - It must read as a rope end cap, not a ball on a stick.
4. **Make the pulley read from this camera.**
   - Cut the camera-side cheek plate down: an open or skeletal plate, or a plate behind the wheel only.
   - Or turn the carriage so the camera sees the wheel face and the groove, with the cable wrapping into the groove.
   - Then nudge the station or camera framing so the wheel and base sit inside the frame with about 20 px of margin, or crop decisively above the base. Nothing should kiss the frame edge.
   - Show a 4x crop of it.
5. **Re-shoot and re-judge.** Re-shoot f0, f30, f55, the hand close-ups at f0/30/55/70, the 960-native rope A/B, and an app-size strip. Re-run contact-log.txt with the same coverage (every 5th frame plus every frame f48-70). Then get a re-judge, and only after that render one clip.

### Accepted, no action
- f55 near stopper overlapping the neck contour in screen space. It is 176 mm or more away in 3D, and the read is comparable to r15's bar at the chin.
- The wrist-skin edge in the close-ups from below.
- The station as a plain column, now that it recedes.
- Body, timing, glow set and grip quality.

## Can the clip render go now?
**No.** Fixes 1-2 are blockers. They are the whole reason this is not premium yet. Fixes 3-4 are cheap and belong in the same pass.
