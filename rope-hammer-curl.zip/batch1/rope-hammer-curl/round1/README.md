# Rope Hammer Curl: round 1 stills

Older first-pass stills (before the fixes below) are in `first-pass/`.

## Files
- `hammer-keys.jpg`: f0 (bottom), f30 (mid lift), f55 (top).
- `hammer-keys-appsize.jpg`: the same at about app size.
- `hammer-f000/030/055.png`: full size.
- `hammer-hands-closeups.jpg`: rows are f0, f30, f55 and f70. Columns are the right hand (clip view, from below) and the left hand (clip view, from below).
- `contact-log.txt`: the contact test, every 5th frame 0-125.
- `hammer.py` (choreography), `render8.py` and `props.py` (build).

## What it is
- Choreography: the approved r15 curl timing, with the changes a hammer curl needs.
  - Neutral grip: the forearms are turned 90° through the forearm twist, not at the wrist.
  - Shoulders flexed 6-11°, so the arms rest a touch in front of the thighs. The cable pulls forward, and this keeps the rope and stoppers clear of the legs.
  - Arms abducted 2°.
  - The level elbow hinge used for rigid and two-handed props.
- **Rope held the real way.** The knobs sit on the side of the fist away from the pulley. On a low pulley that means the rope leaves the pinky side and the knobs sit over the thumbs; at mid-lift the rope drops straight from the bottom of each fist.
  - The first pass had this reversed: the rope U-turned over the top of the fist and ran down in front of the fingers.
- The rope wraps the fist edge on a 17 mm radius. Strands are 0.38 m, so the V spreads like a real rope. The rope exits 6 mm past the hand span.
- The cable runs to a low pulley on a plain column.
  - The camera is turned -38° so the column stands beside him and doesn't block him. The studio turns with the camera, so no cyc edge shows.
- **Glow is on the hammer-curl movers**: biceps, brachialis and brachioradialis. The brachioradialis glows only over its belly on the upper forearm and fades out down the tendon.

## Contact test (log in contact-log.txt)
- Hand skin inside the rope: **0 on every frame**, worst clearance +0.3 mm.
- Rope inside the body or arm hulls: **0**.
- Hand skin against the trunk and legs, using ray parity: **0 inside**. The smallest gap is 97 mm, at the bottom.

## Known, for the judge to rule on
- The column is plain: a box with a carriage and a wheel.
- The wrist-skin edge shows in extreme close-ups, the same as on the approved r15 curl.
- At the top (f55) the near hand covers part of the face from this camera. That is the same as the r15 curl's top.
