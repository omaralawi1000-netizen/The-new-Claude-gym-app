# Rope Hammer Curl (batch 1, round 1): judge verdict

**Verdict: FIX FIRST. Do not render the clip yet.**

The body, the motion and the hands are close: it is r15 with a neutral grip. The forearm twist is clean, and every finger closes on the rope with no penetration in any close-up. The glow is on the right muscles. What fails is the prop. At 960 and at app size the "rope" reads as a bent grey metal pipe, a crank handle or a V-handle bar, not a rope. The stoppers are pawn-shaped, and at f0 the rope hooks round behind the near fist. On top of that, the "rope in body" half of the contact test does not prove what it claims (see item 1). The figure is fine; the prop and its test are not. Omar looks at hands and props closely, so this needs one more stills round.

What I looked at:
- README, figure-rules.md (including the new prop rules), and ez-bar-curl/judge-verdict.md.
- hammer-keys.jpg, hammer-keys-appsize.jpg, and f000/030/055 at native size and at 4x crops of the arms, hands and rope.
- All 14 panels of hammer-hands-closeups.jpg, and first-pass/hammer-keys.jpg.
- r15 f0 and f55 pulled from curl-clip-r15.mp4, set next to the hammer stills.
- Code: render8.py (GLOW_RE, posed, set_frame, the GRIPDIAG rope block at lines 263-335), props.py (rope_geometry, update_rope, make_cable_station), hammer.py, and source/build.py, rig.py and scene.py to see what the UNDER collection actually is.
- There is no Blender here, so I checked the code paths and the pictures but could not re-run the numbers.

---

## Claims checked

| Claim | What I found | Result |
|---|---|---|
| Contact test uses the real meshes | **Hand skin in rope:** the test builds a BVH from the evaluated `Rope` object each frame. That is the same mesh that renders: strands, wraps, stoppers, clip sleeve and cable. It tests every evaluated vertex of that side's SKIN and UNDER objects. The rope tube's normals are consistently outward (`_tube3` winding works out to +N), so the face-normal sign is valid. | **Real for the hands.** One caveat: the segment through the fist is rebuilt every frame from that hand's own grip centre and axis, and the grip was solved for a 13.5 mm bar. "0 inside" there is true by construction; the constant 0.3-0.4 mm clearance on every frame is the sign of that. The test does real work on the wraps, stoppers and strands. |
| "0 rope points inside body/arms" | It tests rope vertices against the **UNDER** collection with a face-normal sign (render8.py:302). UNDER is not a set of closed hulls. It holds the Z-Anatomy *region skin sheets*, merged into `U:body` and `U:arm region.l/r` and sunk under the muscles. build.py:132 says outright "region meshes have mixed winding, so no normals", and no later step recalculates them (only the feet and EggHead get `recalc_face_normals`). The visible **MUS** muscles are not tested at all. **EggHead is not in UNDER**, so the head and jaw are never tested. The cable has only 8 vertex rings over about 1 m, so it is sampled about every 13 cm. | **Not proof.** The sign is unreliable on mixed-winding sheets, and the surface that is tested is not the surface that renders. In the pictures the strands pass in front of the thighs with no visible cut, so this is a test defect, not a visible bug. It is still not the test the rules describe. |
| Hand skin vs trunk and legs: 0 inside, gap 97 mm | Ray parity along +z against `U:body`. `U:body` is an open sheet: the arm regions are split off and the crotch is cut out, so parity is not reliable. The distances are real distances to the under-sheet. "1000000000000mm" means nothing was found within 200 mm, which is a sentinel and not a measurement. | The gaps of 97 mm or more are believable and match the pictures. The "inside" count is not trustworthy as a method. |
| Every 5th frame 0-125 | contact-log.txt has f0-f125 in steps of 5, plus the TOTAL line. | True. The rules ask for **"every 5th frame plus the whole top"**. The top hold (about f50-68) was not run frame by frame. |
| Knobs away from the pulley | `PROP=rope_low` → `ROPE_ENTRY` defaults to 'pinky' → the rope leaves on the pinky side and the stopper sits at T_THUMB. In the stills the knobs sit over the thumbs at f0, f30 and f55. | **True.** The `rope_geometry` docstring (props.py:194-195) still says the opposite ('thumb' for low-pulley curls). Fix the comment so nobody "corrects" the code back. |
| Glow on biceps, brachialis and brachioradialis | `GLOW_RE = 'biceps brachii\|Brachioradialis\|Brachialis muscle'`, case-insensitive. **"Brachialis muscle" is also a substring of "Coraco*brachialis muscle*"**, so coracobrachialis almost certainly glows too. Its band sits mostly in the fade zone, so the effect is small, but it is the wrong muscle. In the pictures, biceps and brachialis read strongly. The brachioradialis reads only as a small extension of the elbow glow (f30 near arm, f0 and f30 far forearm). It does not read as a forearm muscle on the near arm at f0. | Mostly true. One regex bug, and the brachioradialis is weak. |

## Must fix before the clip

### 1. The rope reads as a bent metal pipe (every frame; worst at f0 and f30, near hand)
- **What is wrong:**
  - The rope is a perfectly smooth 27 mm tube in the body's own Clay. At app size (hammer-keys-appsize) it reads as a rigid V-handle or crank, not a rope.
  - The hard 17 mm wraps (`ROPE_WRAP`) look like pipe elbows.
  - **f0, near hand (4x crop):** the strand runs out of the pinky side *backwards*, along the grip axis, past the fist. It then makes a tight hairpin of about 150° and comes back forward to the clip, leaving a hook behind the fist toward the thigh. A taut rope takes the short way: it leaves the heel of the fist already heading for the clip. The far hand at f0 shows a Z-kink of the same kind.
  - The cause is the `phi` arc in `rope_geometry` when the exit direction and the clip direction differ by more than 90°. The exit point sits 6 mm past the hand span, then the arc turns on 17 mm.
- **Fix:**
  - **Material:** give the rope its own value inside the monochrome family: a dark charcoal, about 35-45% of the clay's albedo. Add a subtle three-strand braid bump (helix pitch about 25 mm), and make the stoppers matte black rubber. The red glow must stay the only colour on the page. Show Omar an A/B of clay vs charcoal on one still, because this changes the "one material family" look.
  - **Wrap:** raise the radius to about 30-40 mm. When `phi` is over about 100°, start the bend *inside* the hand span, at the heel of the hand, instead of 6 mm past it, so nothing protrudes behind the fist. As an alternative, let the fist tilt into the rope line through a few degrees of ulnar deviation at the bottom (no more than 10°), which is what a real lifter's hand does under cable tension.
  - Then re-run the contact test: a tighter wrap at the heel is exactly where it can catch the hypothenar.

### 2. The stoppers are pawn- or vase-shaped (every frame, every close-up)
- **Cause:** props.py:239. `rr = KNOB_R*(0.75+0.25*sin(pi*min(1, u/0.045*1.4)))` reaches sin(π)=0 at u=0.032 and then stays there. The radius therefore swells to 24 mm and drops back to 18 mm: a bulb with a neck, ending in a flat disc cap.
- **Fix:** model a real rope end. Use a rounded cylinder about 42-45 mm long with a radius of about 20-22 mm, a soft chamfer where the rope enters, and a domed (hemispherical) far end. A 45 mm ball is also acceptable. Keep it black rubber (item 1).

### 3. The test does not check the rope against the body or the head (render8.py:293-304)
- **Fix:**
  - Test the rope against what renders: the visible **MUS** meshes, SKIN, UNDER and **EggHead**.
  - Use **unsigned** distance from the rope *centreline* samples, every 5 mm along each strand and the cable. Pass when the distance is at least `ROPE_R` (or `KNOB_R` along the stopper), except along the in-fist segment. This avoids normals on open, mixed-winding sheets altogether.
  - Add the forearm MUS of the same side to the hand-vs-rope check, within 4 cm of the rope. The EZ judge flagged this too.
  - Run it every 5th frame **plus every frame f48-70**.
  - Print ">200mm" in place of the 1e12 sentinel.
- Do this before the clip: at f55 the near stopper sits right against the jaw line (item 4), and nothing tests that today.

### 4. Top of the rep (f55, near hand): the stopper merges with the chin and jaw, and the rope does not split
- **What is wrong (h55 at 4x):**
  - The near stopper sits on the jaw and neck outline. At 960 and at app size it reads as a knob pressed into the jaw. r15's top has the bar at the chin as well, but a bar crosses in front; a stopper sitting on the jaw line is a new tangency.
  - The two fists finish narrower than the shoulders, so the V is narrow. A coach expects the rope ends to come apart at the top, finishing at or just outside the front of the shoulders. `abduct` is held at 2°, so nothing opens them.
- **Fix:**
  - Lower the top: elbow peak about 118° instead of 125.6°, keeping the table's shape (scale it).
  - Lower the top shoulder flexion from 11° to about 8°.
  - Add a small split at the top: `abduct` from 2° to about 6-7° over f30-55, held through the squeeze with a creep, and back by f100.
  - Check that the stopper clears the jaw by at least 3 cm, visually and in the new test from item 3.

### 5. Coracobrachialis glow (render8.py:54)
- Anchor the regex, for example `r'^(biceps brachii|brachialis muscle|brachioradialis)'` (check the real object names), or use `\bBrachialis`. Print the matched object names once at build time and paste them into the README.

## Should fix (same pass, cheap)

6. **Wrist channel:** hammer.py carries over the curl's 4→12° wrist flexion. With the hand turned 90°, flexion now folds the fists toward each other instead of curling them up. A hammer curl keeps a straight wrist: use 0-3°.
7. **Brachioradialis band:** it only reads as part of the elbow glow. Extend its lit band to about u 0-0.55 (from 0-0.40), so the upper-forearm belly is red at f30 and f55. Do not light the distal tendon.
8. **Cable station look:**
   - Today the station is a bare clay post with a small box at the floor. At app size the post is the tallest, highest-contrast shape in the frame and pulls the eye off the figure.
   - Make it recede: about 1.5-2 values lighter than the clay, or lower specular and contrast, so the figure stays the subject.
   - Make the low pulley read as a pulley: a visible wheel with cheek plates about 1.5x the current 42 mm wheel. The scale itself is right: a 9 cm upright, 2.3 m tall, on a 42 x 34 cm base.
   - Give the clip a small eye or carabiner where the cable meets the rope sleeve.
9. **Strand length:** at 0.38 m from the exit to the clip, the V is tall (in f30 the apex is near mid-thigh). A standard 27-inch tricep rope gives about 0.24-0.28 m. Try 0.27. figure-rules.md fixes this at 0.38, so changing it is a rules change. Show it on the A/B still.

## Passed / accepted
- **Neutral grip through the forearm twist:** a constant 90° on foretw. At native size and in the close-ups there is no pinch, no candy-wrapper and no flattening, at f0, f30 or f55. The forearm forms hold up as well as on the EZ bar at 22°.
- **Hands on the rope:** in all 14 close-ups the fingers close round the rope, the thumb side carries the stopper, and nothing passes through a finger. The quality is the same as the approved r12/r15 fists. The wrist cuff with tendon gaps shows only from below and is not visible at 960, the same accepted limit as before.
- **Elbows pinned:** the upper arm stays at the side through f30. The 6° resting shoulder flexion, which keeps the rope off the thighs, is honest for a cable pulling forward.
- **Timing:** r15's elbow table, warp and body keys are unchanged, and the loop is unchanged.
- **Camera turn of -38° with the studio turned:** no cyc edge, and the column stands beside him.
- **Knob side:** over the thumbs, correct for a low pulley. The first pass's U-turn over the top of the fist is gone.

## Worse than r15
1. **The prop** (items 1-2): r15's barbell looks like a premium product shot, and this rope looks like plumbing. This is the main regression.
2. **The near stopper on the jaw at the top** (item 4).
3. **The column dominating the right third at app size** (item 8).
4. **Less glow on show:** the turned camera hides the far arm, so one arm carries all the red. That is inherent to the cable camera and acceptable.

## Can the clip render go now?
**No.** Fix items 1-5 (6-9 in the same pass). Then re-render f0, f30 and f55, and the hand close-ups at f0, f30, f55 and f70, plus one A/B still of the rope material. Save the new contact log next to the README and get a re-judge. Then render one clip.
