# Rope Hammer Curl, round 3 (fixes for judge round 2)

The round 2 verdict and files are in `round2/` (`judge-verdict-r2.md`), and round 1 is in `round1/`. Code for this round is in `../code-r3/`. Settings are in `rope4.sh` (contact and close-ups) and `rope5.sh` (keys).

## Fix 1: a braid that reads as rope
- `ROPE_PITCH` is 0.09 m per strand turn, as you asked: three crowns about 30 mm apart, at about 35-40°.
- Bump distance is 2 mm, and the groove multiply is 0.8.
- `rope-ab-native-f030.png` shows round 2 against round 3 at native 960 pixels (1x), then the same crops at x3 nearest-neighbour.
- **Honest note:** at native 960 the twist is a faint texture at best. At 1x the near strand is about 9 px thick, so three crowns can't really resolve. The braid reads in the close-ups. At app size the rope reads by its shape and its rubber caps, not its twist.

## Fix 2: the strand reads as a taut rope, not a bent bar
- **(b, c) One smooth cubic Bezier per strand** (`props.py`, `rope_geometry.strand`).
  - It starts at the fist exit along the grip axis.
  - It bends hardest at the heel of the hand (handle 45 mm).
  - It runs into the sleeve along the cable line (handle 0.30 of the span).
  - There is no straight drop and no corner. The two strands fan into the sleeve tangent to the cable.
  - The clip position is solved on the Bezier's arc length, so the strands stay 0.27 m long.
- **(a) Fist tilt into the rope line:**
  - Up to 10°, scaled by the turn angle, and signed by how much of the turn a side tilt can take.
  - That signing makes it pass smoothly through 0. A first version flipped sign between frames: a 10° wrist snap, caught and fixed before this round.
  - In practice it is -4.5° to +2.8° over the rep (the ROPETILT lines in `contact-log.txt`). The Bezier does most of the work.
- **(d)** The f0 far-hand Z-kink is gone (close-ups, left hand, f0).
- **Contact** (`contact-log.txt`, every 5th frame plus every frame f48-70, 44 frames):
  - **0** hand-skin points inside the rope, worst clearance 0.3 mm.
  - Rope vs body or head: 0 crossings, min clearance 2.1 mm (left strand against the flexor digitorum superficialis).

## Fix 3: stopper silhouette
- Radius 21 mm (kept), total length 49 mm.
- A 13 mm cone taper from the rope, a straight body, and a flat end with a 7 mm fillet. The hemisphere is gone.
- See the close-ups and `hammer-f030.png`.

## Fix 4: the pulley reads, and nothing touches the frame edge
- The camera-side cheek plate is gone. The wheel sits in an open fork (two thin arms, an axle and nuts), so you see the wheel face and the groove.
- The cable leaves the clip eye and reaches the wheel at its rim. In the geometry it meets the groove at its front tangent and wraps into it, but from this camera the wrap is hidden behind the wheel face. What reads is a cable running to the edge of a wheel.
- The carriage block behind the wheel still reads as a plain grey box.
- **Framing:** all cable moves now use `CAM_LENS=43` (was 48), and the hammer uses target height 0.80 (was 0.85).
  - The base now ends at row 617 of 640, a 22 px margin, and the wheel sits well inside.
  - Head room is about 45 px. The figure is about 10% smaller than the barbell curl's framing.
- `pulley-4x-f030.png`: 4x, with the bottom frame edge drawn in red.

## Fix 5: re-shoot
- `hammer-keys.jpg` (f0/30/55), with `hammer-f000/030/055.png` at full 960x640.
- `hammer-keys-appsize.jpg`.
- `hammer-hands-closeups.jpg`: both hands, from the clip side and from below, at f0/30/55/70.
- `contact-log.txt`.

No clip yet. It renders after your verdict.
