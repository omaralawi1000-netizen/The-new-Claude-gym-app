PASS. Score: 9.1 / 10.

# Rope Hammer Curl, clip 2: judge verdict (judge round 7)

The round-6 failure is fixed. Through the top of the rep (f45-76) the near end cap sits clearly inside the chest outline, with
body all round it, so it reads as being in front of him and not resting on the neck or trapezius. With the elbows pinned the move
looks more like a strict hammer curl than clip 1 did. The flaws that remain are all in transit, all 1-5 px, and none of them
shows at app size. They are listed below so the next pass can tidy them, but none of them blocks.

## What I looked at myself
- All 130 frames, extracted from both `hammer-clip-2.mp4` and `.webm`, plus the lossless keys `clip-f000/030/055.png` and every sheet in this folder.
- My own crops (scratchpad `judge-r7/`): the cap every frame f38-85 at x3-x4 (`ham-cap-38-61.png`, `ham-cross-36-47.png`,
  `ham-cross-74-85.png`), the upper body at f0/20/30/40/46/52/58/64/70/90 at x2 (`ham-upper-keys.png`), the far fist through the
  hold at x5 (`ham-far-48-71.png`), an app-size sheet at 384 px wide (`ham-appsize.png`), and x8 crops of every speck candidate (`ham-specks-x8.png`).
- **Whole-frame pinhole scan, every frame:** pixels above 180 with at most 6 bright pixels in a 9x9 window and at least 60 dark ones.
  Every hit is a lit highlight: the cap's metal (f38, f86), knuckle and finger tops (f53, f68, f74), and the steady ab/hip ridge
  highlight at (322,300). **No background pinholes anywhere in the clip.**
- **Motion:** blurred per-step change, every step. It rises and falls smoothly, with no spike or double bump, and eases into the
  top (f56-62) and the bottom (f122-128). The step at 129→0 (0.15 against 0.04) is the encoder keyframe, the same as clip 1.

## Item by item

| Check | Finding | Verdict |
|---|---|---|
| Cap on the neck/trap outline (r6 must-fix) | f45-76: the cap is inside the pec, with body above and to the right of it on every frame. It no longer touches the shoulder line. | **Fixed.** |
| Cap crossing the side outline, f36-44 and f77-80 | The cap sweeps across the lat/pec edge as the fist comes forward from the hip. It is half over background for about 3 frames (f37-40 in my crops), then inside. It moves 4-6 px a frame and never stops on the edge. It reads as a fist passing in front of the torso, which is what it is. Mirrored on the way down. | **Accepted (transit, ≤5 frames each way).** |
| Pose change (elbows pinned, upper arm -5 deg at top) | The elbow stays at the side of the ribs all the way up. The forearm rises to the upper pec, and the fist ends in front of the chest at about nipple-to-collarbone height. That is a strict hammer curl. The top is a little lower than clip 1, but still a full contraction. | **Natural. Better than clip 1.** |
| Fist turn 20 deg | Visible only as the knuckles showing a little more to the camera at the top. There's no wrist kink or candy-wrapper twist on the forearm. The rope still runs out of the fist the way it should. | **Natural.** |
| Red edge stripe on the far forearm, f36-47, f51-55, f64-69, f72-85 | A 1-3 px line of saturated red (not pink) where the far brachioradialis shows between the near fingertips and the near strand. It grows and shrinks smoothly. At x3 it reads as the mover's edge. At app size it can't be seen. | **Cosmetic.** |
| Red window under the near cap, f84-86 | About 3x5 px of red on each side of the near cap (x8 crop f86). It's the far mover, the right colour, for 3 frames on the way down. Invisible at app size. | **Cosmetic.** |
| f35 speck | 1 frame, 1.8 px, red. I can't see it at x3 in the mp4. | **Not visible.** |
| Hands on the rope | The fingers wrap the rope on every frame I looked at. There's no slide and no pop of the grip. | **Pass.** |
| Glow, red, loop | Clean anti-aliased edges. The red matches clip 1. The loop is smooth. | **Pass.** |

## Flaws, ranked (none blocks)
1. Red 1-3 px edge stripe on the far forearm beside the near fingertips: f36-47, f72-85 (strongest f48 and f72 at about 3x2 px).
2. Red window either side of the near cap, f84-86.
3. Cap half over background as it crosses the side outline, about f37-40 and f78-80 (transit).
4. Encoder keyframe step at the loop seam, 129→0. Not motion. Same as every clip.

## To make it a 9.5 (optional)
- Cut the far-arm glow wherever its visible run beside the near fist is under 4 px, so the stripe in (1) and the window in (2) go back to clay.

## Taken from the thread, not re-run (no Blender here)
- The CAPDIAG, SLIVERDIAG, TILTDIAG and contact numbers. They agree with what I see in the pixels.

## Can it ship?
**Yes.**
