# Rope Hammer Curl, clip 2 (after judge round 6)

Clip: `hammer-clip-2.mp4` / `.webm` (130 frames, 30 fps, 4.3 s loop, 960x640). Code: `../../code-r7/`.
Everything below is self-checked, not judged.

## Must-fix 1: near end cap on the trapezius/neck outline (f46-70)
- **Change (both arms, a visible pose change, please judge it):** at the top the upper arm eases back to -5 deg instead of forward +7.8 deg (`shoulder`), so the elbows stay pinned at his sides. The fists turn 20 deg from thumbs-up through the top (`twist` 90 → 70, back to 90 by f105). The wrist stays 0-3 deg, as judge r2 asked.
- **Result (`cap-log.txt`, CAPDIAG, every frame):** the cap sits inside the chest outline on **f45-76**, with 5.0-7.6 px from cap to background (so at least 4 px of body between). Sheet: `cap-f40-78-x3.png`.
- **Please look at f40-44 and f77-80.** Your pass line asks for inside-or-clear on every frame f40-75. f40-44 does not meet it:
  - This is where the fist travels from beside the hip to in front of the chest, so the cap has to cross the side outline once. It does so at speed: cap pixels over background go 60 → 23 → 5 → 0 on f40-43, and the margin is 2.0-2.2 px on f43-44.
  - I tried moving the twist and shoulder ramps 4-6 frames earlier (variants hmE1/hmE2). The crossing frames did not move (f44 margin 2.2 → 3.0), because the elbow curl, not the twist, sets them. So I kept the timing.
  - The way down mirrors it: margin 2.0/1.0 on f77-78, then the cap leaves the outline on f79-80.

## Nice-to-have: pink speck on the far forearm
- **New check, SLIVERDIAG** (`far-forearm-sliver-log.txt`): 2x2 rays per pixel round the near fist. It finds visible pieces of the far arm's movers (brachioradialis, biceps, brachialis) smaller than 8 px.
- **What it was:** a 1-3 px sliver of the far brachioradialis showing under the near fingers on the lift (f35-43), plus a 2 px red corner between rope and far forearm through the top (f52-68). At 1-2 px it reads pink.
- **Change:** the far elbow runs 2 deg ahead of the near one from the lift to the end of the squeeze (`elbow_l`, ramp f20-40, hold to f70, back by f82). The long ramp keeps the rope tilt smooth (below).
- **Left (please look, `far-forearm-f35-44-84-86-x6.png`, `far-forearm-top-hold-f48-72-x4.png`):**
  - f35: one frame of 1.8 px, as a small window behind the near fist closes.
  - f84-86: a window under the near cap opens and the far brachioradialis shows in it (3.0 / 1.0 / 4.8 px, then 10, 18 px). It renders red (164,45,41), not pink. Six far-arm variants (elbow ±, abduct ±, twist ±) left it unchanged, because the near cap and hand make the window.
  - f44 and f51-55 / f64-69: a 1-2 px red stripe along the edge of the far forearm next to the rope. It grows and shrinks smoothly and shrinks to 0-1 px at f57-63. It is the muscle's edge, red (R-G 46-104), not a lone speck. `pink-scan-far-forearm.txt` lists every frame.

## Contact (`contact-log.txt`, all 130 frames)
- **Hands:** 0 hand-skin points inside the rope, worst clearance 0.3 mm.
- **Rope shape:** ROPESTRAIGHT 0.00 mm. ROPEMONO worst back-step 0.6 mm.
- **Rope vs body:** 0 crossings, at least 2.1 mm. Rope vs head at least 116 mm (clip 1: 103 mm).

## Tilt (`tilt-log.txt`, TILTDIAG, every frame)
- **Max |2nd diff|:** 0.139 (r, f36) / 0.144 (l, f33) deg/f², pass 0.15. My first far-elbow ramp (f30-36) pushed the far side to 0.187, so I lengthened it to f20-40.
- No run of 3 identical non-zero values. Tilt is 0.0 by design where phi < 45 deg (f37-82).

## Other checks
- **Motion (`clipcheck.txt`):** no spikes; loop seam 0.134 against a per-step median of 0.472.
- **Colour (`colour-log.txt`):** red core 220/48/31-32, lightness 0.550-0.552 (clip 1: 0.553).
- **Light spots near the hands:** a bright-in-dark scan finds 12 frames with 6-16 px spots up to 182. PICKDIAG on the brightest one (f82, 364,205) says it is the lit body under-layer in a slot between muscles, not background (background is about 240). Clip 1 had the same 13 frames.
- **Frames that changed from clip 1:** f19-110 (shoulder and twist on both arms, far elbow f20-82). f111-129 and f0-18 are the same pose as clip 1.

## Files
- `hammer-clip-2.mp4`/`.webm`, `clip-f000/030/055.png`, `clip-every-10th-frame.png`.
- Sheets: `clip1-vs-clip2-f055-x2.png` (the pose change), `cap-f40-78-x3.png`, `far-forearm-f35-44-84-86-x6.png`, `far-forearm-top-hold-f48-72-x4.png`.
- Logs: `cap-log.txt`, `far-forearm-sliver-log.txt`, `pink-scan-far-forearm.txt`, `contact-log.txt`, `tilt-log.txt`, `clipcheck.txt`, `colour-log.txt`.
