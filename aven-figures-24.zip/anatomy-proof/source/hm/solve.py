import sys, json
from handmodel import *
GAP = 0.0003
def solve(side, s, sink=0.0, t0=(14, 8), verbose=False, a_over=None):
    J = {k: np.array(v) for k, v in JS[side].items()}
    P0 = D[side + '_P']; Bn = D[side + '_B']
    mcp = np.array([J['f%d' % i][1] for i in range(1, 5)]); m0 = mcp.mean(0)
    a = nrm(J['f4'][1] - J['f1'][1]) if a_over is None else nrm(np.array(a_over[side]))
    dd = nrm(np.mean([J['f%d' % i][2] - J['f%d' % i][1] for i in range(1, 5)], 0)); dd = nrm(dd - (dd @ a) * a)
    n = np.cross(a, dd); n = n if n @ FWD > 0 else -n
    A = {'f%d' % i: [0.0, 0.0, 0.0] for i in range(1, 5)}; A['t'] = [np.radians(t0[0]), np.radians(t0[1]), 0.0, 0.0]
    # bar height: touch the palm-side skin of the hand and the finger roots (rest) around the bar line, from in front
    G, _ = transforms(side, A); Q = skin(side, G)
    rel = Q - m0; along = rel @ dd; lat = rel @ a
    loc = (np.abs(along - s) < 0.009) & (lat > -0.01 + (mcp - m0)[0] @ a) & (lat < 0.01 + (mcp - m0)[3] @ a) & (np.char.startswith(Bn, 'f') | (Bn == 'hand'))
    # bar centre at height H along n: need every local vert at distance >= R from the axis
    def pen_at(H):
        c = m0 + n * H + dd * s; d, t, _ = bar_dist(Q[loc], c, a); return (d < R_BAR + GAP).sum()
    H = 0.0
    for H in np.arange(0.0, 0.06, 0.0005):
        if pen_at(H) == 0: break
    H += sink
    c = m0 + n * H + dd * s
    fv = {i: np.nonzero(np.char.startswith(Bn, f'f{i}'))[0] for i in range(1, 5)}
    LIM = [np.radians(95), np.radians(115), np.radians(85)]
    for i in range(1, 5):
        for j in range(3):
            def pen(th):
                A['f%d' % i][j] = th; G, _ = transforms(side, A); Qf = skin(side, G)[fv[i]]
                return (bar_dist(Qf, c, a)[0] < R_BAR + GAP).sum()
            th = 0.0
            if pen(0.0):
                while th > -np.radians(25) and pen(th): th -= np.radians(1)
            else:
                while th < LIM[j] and not pen(th + np.radians(1)): th += np.radians(1)
            A['f%d' % i][j] = th
    tv = np.nonzero(np.char.startswith(Bn, 't'))[0]
    for j in (2, 3):
        def pen(th):
            A['t'][j] = th; G, _ = transforms(side, A); return (bar_dist(skin(side, G)[tv], c, a)[0] < R_BAR + GAP).sum()
        th = 0.0
        if pen(0.0):
            while th > -np.radians(30) and pen(th): th -= np.radians(1)
        else:
            while th < np.radians(85) and not pen(th + np.radians(1)): th += np.radians(1)
        A['t'][j] = th
    G, _ = transforms(side, A); Q = skin(side, G); d, t, rad = bar_dist(Q, c, a)
    hug = (d < R_BAR + 0.002) & (np.abs(t) < 0.06); e1 = n; e2 = np.cross(a, e1)
    ang = np.degrees(np.arctan2(rad[hug] @ e2, rad[hug] @ e1)) % 360
    cover = len(np.unique((ang // 10).astype(int))) * 10; pen = int((d < R_BAR - 0.0003).sum())
    # per finger: is the fingertip pad touching the bar (or the palm)?
    return dict(s=s, H=H, cover=cover, pen=pen, A={k: [round(float(np.degrees(x)), 1) for x in v] for k, v in A.items()}, c=c.tolist(), a=a.tolist(), Arad={k: [float(x) for x in v] for k, v in A.items()})
if __name__ == '__main__':
    side = sys.argv[1] if len(sys.argv) > 1 else 'r'
    for s in np.arange(-0.006, 0.031, 0.004):
        r = solve(side, s); print('s %.3f H %.1fmm cover %d pen %d' % (s, r['H'] * 1000, r['cover'], r['pen']), r['A'])
