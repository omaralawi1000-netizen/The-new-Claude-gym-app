import numpy as np, sys, json, time
from handmodel import *
from solve import solve
from scipy.spatial import cKDTree
def nrmv(v): v=np.array(v,float); return v/np.linalg.norm(v)
ax={'r':nrmv([0.9778,-0.0923,-0.1292]),'l':nrmv([-0.9778,-0.0923,-0.1292])}
side=sys.argv[1]; s=float(sys.argv[2])
base=solve(side,s,t0=(25,12),a_over=ax); c=np.array(base['c']); a=np.array(base['a'])
A={k:list(v) for k,v in base['Arad'].items()}
Bn=D[side+'_B']; P=D[side+'_P']; names,Wm=weights(side)
tv=np.nonzero(np.char.startswith(Bn,'t'))[0]; tip=np.nonzero(Bn=='t2')[0]
fv=np.nonzero(np.char.startswith(Bn,'f1')|np.char.startswith(Bn,'f2'))[0]
def skin_sub(G,idx):
    out=np.zeros((len(idx),3)); Pi=P[idx]
    for k,nm in enumerate(names):
        w=Wm[idx,k]
        if w.max()==0: continue
        M=G.get(nm,np.eye(4)); out+=w[:,None]*(Pi@M[:3,:3].T+M[:3,3])
    return out
G,_=transforms(side,A); F=skin_sub(G,fv); tree=cKDTree(F)
res=[]
for t0a in range(0,75,5):
  for t0b in range(-15,45,5):
    A['t'][0]=np.radians(t0a); A['t'][1]=np.radians(t0b)
    for j in (2,3):
        def pen(th):
            A['t'][j]=th; G,_=transforms(side,A); Q=skin_sub(G,tv); return (bar_dist(Q,c,a)[0]<R_BAR+0.0003).sum()
        th=0.0
        if pen(0.0):
            while th>-np.radians(30) and pen(th): th-=np.radians(1)
        else:
            while th<np.radians(85) and not pen(th+np.radians(1)): th+=np.radians(1)
        A['t'][j]=th
    G,_=transforms(side,A); Q=skin_sub(G,tv); d=bar_dist(Q,c,a)[0]
    hug=int((d<R_BAR+0.002).sum()); pen0=int((d<R_BAR-0.0003).sum())
    dd,_=tree.query(Q); overlap=int((dd<0.0015).sum())
    Qt=skin_sub(G,tip); dtip=float(tree.query(Qt)[0].min())
    res.append((hug,t0a,t0b,round(np.degrees(A['t'][2])),round(np.degrees(A['t'][3])),pen0,overlap,round(dtip*1000,1)))
res=[r for r in res if r[5]==0]; res.sort(reverse=True)
print('fingers',base['A'],'cover',base['cover'])
for r in res[:25]: print('hug %d t0 %d %d t1 %d t2 %d pen %d overlap %d tipdist %.1fmm'%r)
