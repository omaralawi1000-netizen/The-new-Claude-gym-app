# numpy model of the hand rig (rest hand frame): linear-blend skinning of the hand skin with the rig's own weights
import json, ast, numpy as np
AP = '/tmp/claude-0/-home-user-The-new-Claude-gym-app/d51340df-4d5a-5fae-b90f-1a55e40a4dc4/scratchpad/ap/'
JS = json.load(open(AP + 'joints.json')); FWD = np.array([0, -1.0, 0]); R_BAR = 0.0135
D = np.load('/tmp/claude-0/hand_rest.npz')
def nrm(v): return v / np.linalg.norm(v)
def flex_axis(d, n=FWD):
    n = n - (n @ d) * d; return nrm(np.cross(d, nrm(n)))
def rot_about(p, ax, th):
    ax = nrm(np.asarray(ax, float)); c, s = np.cos(th), np.sin(th); K = np.array([[0, -ax[2], ax[1]], [ax[2], 0, -ax[0]], [-ax[1], ax[0], 0]])
    R = np.eye(3) * c + s * K + (1 - c) * np.outer(ax, ax); M = np.eye(4); M[:3, :3] = R; M[:3, 3] = p - R @ p; return M
def ap(M, p): return M[:3, :3] @ p + M[:3, 3]
def transforms(side, A):
    """A: {'f1':[mcp,pip,dip],...,'t':[t0a,t0b,t1,t2]} radians -> bone matrices (hand = identity)"""
    J = {k: np.array(v) for k, v in JS[side].items()}; sgn = -1 if side == 'r' else 1
    G = {'hand': np.eye(4)}
    for i in range(1, 5):
        c = J['f%d' % i]; prev = G['hand']
        for j in range(3):
            d = nrm(c[j + 2] - c[j + 1]); prev = prev @ rot_about(c[j + 1], flex_axis(d), A['f%d' % i][j]); G[f'f{i}{j}'] = prev
    c = J['f0']; d0 = nrm(c[1] - c[0]); med = np.array([-sgn * 1.0, 0, 0])
    t0 = G['hand'] @ rot_about(c[0], flex_axis(d0), A['t'][0]) @ rot_about(c[0], flex_axis(d0, med), A['t'][1]); G['t0'] = t0
    d1 = nrm(c[2] - c[1]); G['t1'] = t0 @ rot_about(c[1], flex_axis(d1, med), A['t'][2])
    d2 = nrm(c[3] - c[2]); G['t2'] = G['t1'] @ rot_about(c[2], flex_axis(d2, med), A['t'][3])
    return G, J
_WC = {}
def weights(side):
    if side not in _WC:
        Ws = [ast.literal_eval(w) for w in D[side + '_W']]; names = sorted({k for w in Ws for k in w})
        Wm = np.zeros((len(Ws), len(names)))
        for r, w in enumerate(Ws):
            for k, x in w.items(): Wm[r, names.index(k)] = x
        Wm /= np.maximum(Wm.sum(1, keepdims=True), 1e-9); _WC[side] = (names, Wm)
    return _WC[side]
def skin(side, G):
    P = D[side + '_P']; names, Wm = weights(side); out = np.zeros_like(P)
    for k, nm in enumerate(names):
        M = G.get(nm, np.eye(4)); w = Wm[:, k]
        if w.max() == 0: continue
        out += w[:, None] * (P @ M[:3, :3].T + M[:3, 3])
    return out
def grip_angles(g, k=1.0):
    r = np.radians; A = {'f%d' % i: [r(62) * g, r(92) * g, r(48) * g] for i in range(1, 5)}
    A['t'] = [r(38) * g * k, r(30) * g * k, r(30) * g, r(35) * g]; return A
def circ_centre(side, A):
    G, J = transforms(side, A); c = J['f2']
    p = [ap(G['hand'], c[1]), ap(G['f20'], c[2]), ap(G['f22'], c[4])]
    u, v = p[1] - p[0], p[2] - p[0]; n = np.cross(u, v)
    return p[0] + (np.cross(n, u) * (v @ v) + np.cross(v, n) * (u @ u)) / (2 * (n @ n))
def bar_dist(Q, c, a):
    q = Q - c; t = q @ a; rad = q - np.outer(t, a); return np.linalg.norm(rad, axis=1), t, rad
