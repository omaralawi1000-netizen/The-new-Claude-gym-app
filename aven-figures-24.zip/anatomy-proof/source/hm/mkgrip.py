import numpy as np, sys, json
from handmodel import *
from solve import solve
def nrmv(v): v=np.array(v,float); return v/np.linalg.norm(v)
ax={'r':nrmv([0.9778,-0.0923,-0.1292]),'l':nrmv([-0.9778,-0.0923,-0.1292])}
s=float(sys.argv[1]); t=[float(x) for x in sys.argv[2].split(',')]; out=sys.argv[3]
G={}
for side in 'rl':
    r=solve(side,s,t0=(t[0],t[1]),a_over=ax); A={k:list(v) for k,v in r['Arad'].items()}
    A['t']=[float(np.radians(x)) for x in t]
    Gm,_=transforms(side,A); Q=skin(side,Gm); d=bar_dist(Q,np.array(r['c']),np.array(r['a']))[0]
    print(side,'pen',int((d<R_BAR-0.0003).sum()),'min %.1fmm'%(d.min()*1000),{k:[round(np.degrees(x)) for x in v] for k,v in A.items()})
    G[side]=dict(c=r['c'],a=r['a'],A=A,s=s,t0=t[:2])
json.dump(G,open(out,'w'),indent=1)
