# Judge verdict clip8-r12: FAIL (stills 8.3, motion 8.4 from stills only, rope 8.2)
Main reason: the junction fill added a NEW flat grey patch with a dotted white outline at the near fist/rope (f44-f66, worst f52-f62), and the dark far-forearm wedge behind the elbow is smaller but still there at f14-19 and f90-96.

Viewed (final frames, 3-8x crops): f0,5,8,11,12,14,16,18,19,20,24,27,28,29,30,31,32,33,34,35,36,37,38,40,44,48,52,54,56,57,58,59,60,61,62,63,64,66,68,69,70,71,72,73,74,76,80,84,88,90,92,94,96,98,100,101,105,110,115,120,122,125,127,129 (64 frames). mp4 not played. Coords are full-frame 960x640.

## Previous must-fixes
1. Far-forearm wisp: PARTLY FIXED, NOT GONE. f11, f12 clean. f14 small dark wedge ~(330-350,276-286). f16-19 grows, ~(331-353,280-294), dark streaked wedge pointing out behind the elbow (reads as a hair/shadow smear). f92 ~(330-353,278-290), f94/f96 ~(330-353,276-286). f90 reads as a real far forearm (fine). f98+ clean. Smaller than clip7 but a viewer still sees a dark pointed streak. MUST-FIX.
2. Light flecks 3-6 px at junction: MIXED. The old white dots are mostly gone, but the fill made worse things (below). Remaining small pale dots: f33 ~(358-361,342-345); f58-62 two white dots ~(349-352,345-348); f73 ~(343-346,350-353); f71 ~(339-343,349-353) a dashed white cluster. Also light crumbly halo around the far fingers and under the fist edge on most frames f29-f80 (e.g. f31 ~(356-362,360-364), f80 ~(335-345,345-352)).
3. Far strand flat dark rod: PARTLY FIXED. Colour is lighter and the lay is visible on the near strand, but the far strand (right side of the triangle, f27-f90) is still smoother and darker than the near strand (f30, f33, f40 ~(358-380,285-350)). Two materials still read at 3x, less at 1x.

## NEW problems
- MUST-FIX: filled patch at near fist/rope, f44-f66 (strongest f52-f62). A flat mid-grey triangle ~(327-336,345-358) with a dotted/dashed white outline, no texture, sitting between the rope and the fingers. It fades in around f44 and out by f68, so it is a visible "dotted shape" for about 25 frames. At f58-62 it is 10x12 px with clear white dots on its right edge. This is exactly the pinhole/dotted look Omar bans. Needs a proper fill (rope/shadow tone with texture, soft edge), no white dots.
- Fuzzy pale crumbs on the outline of fingers/fist junction f29-f40, f68-f80 (light grey blobs 3-5 px off the silhouette). Not flicker between neighbours (f28-34, f58-62 are stable frame to frame), but the crumbs change shape slightly per frame so they shimmer a little.
- Far hand closer at the top (f0-8, f105-129): looks natural. Far fist sits just behind the near fist, no intersection, no hand-through-forearm. OK.
- Rope colour/lighting: consistent now between strands at lockout and top; no flicker in value seen between neighbours. OK except the far strand smoothness above.
- Slivers at flagged frames (0-3,11,12,36,37,73-76,100,119,121-129): f0, 11, 12, 36, 37, 73-76, 100, 120-129 viewed. No pink slivers, no dark wisp (the box was narrowed, but the real wisp frames are f14-19/f92-96 and are not in the flagged list; gate missed them).
- Loop seam f129->f0: clean, no pop.

## Scores
Stills 8.3, motion 8.4, rope 8.2. Lockout arms, glow, knob, bend, hold on both strands, loop seam are good.

## MUST-FIX
1. f44-f66 near junction ~(327-336,345-358): flat patch with dotted white outline. Redo fill.
2. f14-f19 ~(331-353,276-294) and f92-f96 ~(330-353,276-290): dark wedge. Hide behind torso, tuck more, or lighten to skin.
3. White dots: f58-62 (349-352,345-348), f71 (339-343,349-353), f73 (343-346,350-353), f33 (358-361,342-345).

## Nice-to-have
Far strand same lay contrast as near strand; remove pale crumbs around fingers f29-f40 and f68-f80; smoother edge on the junction.

## Taste-only (phone viewer would not notice)
Cube knob shape; far strand slightly smoother than near; pale halo crumbs 3-5 px; fingers slightly open on near hand f76-84.

## Verdict: FAIL (below 9). The patch with dotted edge is the one a viewer will catch on a 120 Hz phone; the wedge at f14-19 is the second.
