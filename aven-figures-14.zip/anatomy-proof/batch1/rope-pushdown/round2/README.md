# Rope Pushdown, round 2 (fixes for judge round 1)

Round 1 files and the verdict are in `round1/` (`judge-verdict.md`). The rope prop is shared with the hammer curl, so the hammer's round 3 fixes are in here too (see `../rope-hammer-curl/README.md`): braid, smooth Bezier strands, continuous fist tilt, stopper caps and the open-fork pulley. Code is in `../code-r3/`; the motion is `motions/pushdown.py` in the scratchpad (copied as `pushdown.py` in code-r3).

## Item 1: the prop
- Charcoal braided rope, black rubber end caps, and one smooth Bezier per strand. No pipe elbows.
- A steel sleeve with an eye at the clip.
- There is no clay A/B still this round. The hammer's `rope-material-ab.jpg` (round 2) showed it.

## Item 2: lockout split and staging
- **Pulley:** 0.45 m in front of the feet (`COL_HIGH_Y=0.55`), wheel centre at 1.80 m.
- **Strands:** 0.27 m.
- **Turn-out and split:**
  - `twist` 90 → 116 at f48 → 120 at f60.
  - `abduct` 2 → 6 at f48 → 7 at f60.
  - Both start at the bottom of the push (f24-26) and creep on. There are no flat holds.
- **Honest note:** from the -65° camera the split does **not** read at lockout. The V lies in his frontal plane and this camera sees it edge-on. The near fist and its cap show at the thigh, and the far fist is behind the hip. See `camera-angle-ab.jpg`, below.

## Item 3: the pulley in frame
- The wheel and fork are fully in frame at the top, about 18 px from the edge (`pulley-4x-f000.png`, red line = frame edge).
- The cable runs straight down from the wheel to the clip.
- The base sits inside the frame with about 30 px of margin.
- Framing for all cable moves: `CAM_LENS=43`, with target height 0.90 for the pushdown.

## Item 4: triceps glow and camera
- The glow is the three triceps heads, lit t 0.12-0.75, the whole horseshoe.
- **Camera A/B** (`camera-angle-ab.jpg`, f20 and f48 at orbits -65, -80, -105 and -125):
  - **-105 (rear three-quarter) is my pick.** Both triceps glow as full red bellies, the split reads at lockout with the caps outside both thighs, and the column and cable stand beside him.
  - The cost: his face turns away.
  - The keys and close-ups in this folder are still at -65. If you agree on -105, I re-shoot the keys at -105 before the clip. The judge wanted this A/B put in front of Omar.

## Item 5: no dead stops
- Every channel creeps through lockout (f48 → f60). See the motion diff in `round1/pushdown.py` against `pushdown.py`.
- Pelvis goes -6.2 → -6.35, shoulder 10.6 → 10.3.

## Item 6: contact test (`contact-log.txt`)
Coverage: every 5th frame, plus f0-5, f44-62 and f112-129, 60 frames.
- **0** hand-skin points inside the rope (same-side forearm muscle included), worst clearance 0.3 mm.
- Rope against MUS, SKIN, UNDER and EggHead: unsigned centreline distance, **0 crossings**, min clearance 5.9 mm (left cap against the flexor digitorum superficialis). Rope to head is at least 131 mm.
- **Fixed this round:** with the hammer's 12 mm in-fist bend inset, the rope cut the thumb side of the hand at f25-30 (8 points, 3.8 mm). The pushdown turn is only 60-66°, so it now uses `ROPE_INSET=0`. The bend starts at the fist edge, and all frames read 0.

## Files
- `pushdown-keys.jpg` (f0/20/48) and `pushdown-f000/020/048.png`.
- `pushdown-keys-appsize.jpg`.
- `pushdown-hands-closeups.jpg`: both hands, clip side and from above, f0/20/48/60.
- `camera-angle-ab.jpg`, `pulley-4x-f000.png` and `contact-log.txt`.

No clip yet.
