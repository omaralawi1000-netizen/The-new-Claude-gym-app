# Rope Pushdown, round 3 (fixes for judge round 2)

Round 2 files and the verdict are in `round2/` and `judge-verdict-r2.md`. The rope prop is shared with the hammer curl, so the rope fixes below cover both moves. The code is in `../code-r4/`. Settings are in `rope8.sh` (close-ups) and `rope9.sh` (keys).

## Camera: -105, with the column moved off the hands
- **Camera:** -105 is used for all keys, close-ups and logs.
- **Moving the column:** neither an orbit tweak (-90 to -125) nor a sideways column fixed the overlap. The near fist sweeps about 60 px across the image during the rep. Moving the column sideways only moves it in depth from this camera.
- **What worked:** the column now stands 1.0 m out (`COL_HIGH_Y=1.0`). The pulley stays exactly where it was (`HIGH_Y=0.44`, wheel at 1.80 m), hung from a lat-tower boom. The cable and rope geometry are therefore unchanged.
- **Framing check** (`framing-log.txt`): `CAMDIAG` checks every second frame of all 130 (65 frames). It gives the near fist's signed pixel distance to the column's silhouette, the composition centre and the margins.
  - The near fist is at least **39 px** from the column on every frame (worst f96). It is 40-75 px at the keys.
  - The figure plus station midpoint is **+10 px** from x = 480 on every frame (`CAM_PAN=0.33`).
  - The pulley/head top margin is 33 px. The boom top is about 24 px from the frame edge (`pulley-4x-f000.png`, red line = frame edge). The base margin is 41 px.
- **The -65/-105 pair for Omar:** `camera-pair-65-vs-105.jpg` shows f20/f48 at both angles with the same station. -105 is the pick.

## Inverted V at lockout
- **Strands:** 0.33 m (was 0.27). At 0.27 the clip sat only 8 mm above the rope exits at f48, and 0.30 still gave 11 mm at f60.
- **Clip height** (`contact-log.txt`, per frame):
  - At lockout the clip is **143 mm** above the exits and 150 mm above the fists (worst f59-61; f48 is higher).
  - At the top it is 238 mm above the exits and **281 mm** above the fists (f0).
- **What you see:** `rope-x4-f000-f020-f048.png` shows the V clearly at f0/f20. At f48 the far strand runs behind his hips from this camera. The far cap shows outside the far thigh and the near cap outside the near hand.

## Taut strands (shared with the hammer)
- **Strand shape:** the heel handle shrinks with the turn: `HEEL x cos(phi/2) x min(1, D/0.15)`. The fan is 0.15 and the fist tilt is capped at 8°.
- **`ROPEMONO`:** a new check in `GRIPDIAG`. It projects each strand from the fist exit to the clip onto the clip-to-pulley line. **0 violations** (worst back-step 0.0 mm) over all 60 tested frames.
- **Contact,** same 60 frames:
  - **0** hand-skin points inside the rope, worst clearance 0.3 mm.
  - Rope against body or head: **0 crossings**, min clearance 5.9 mm (left cap against the flexor digitorum superficialis).
  - Rope to head is at least 128 mm.

## Pulley
- **Rim ring:** a darker inset ring on each wheel face (`StationDark`, 45% of the station value).
- **Cable path:** the cable rides on the rim (`ROPE_RG` 1 mm). It wraps over the top and runs back under the boom into the carriage block (`pulley-4x-f000.png`).

## Triceps: two heads
- **Glow change for this move only:** `GLOW_FACE_MIN=0.35 GLOW_EMIT=0.055 GLOW_AO=0.5 GLOW_AO_D=0.03`. That adds stronger facing falloff plus a short-range AO darkening in the grooves between heads.
- **Result:** the long head and the lateral head now read as two bellies with a darker groove between them (`triceps-x6-f020-f048.png`).
- **Honest notes:**
  - At 1x the groove is subtle.
  - The red is about 3% darker than the curl's biceps: mean pixel 215/65/52 against 222/76/60 at the same glow settings.
- **Top edge:** it is the posterior deltoid's border lying over the triceps. I tested a lower band top (`TRI_T1` 0.62 and 0.45). 0.62 changed nothing visible, and 0.45 dimmed the top third of the triceps. The band is unchanged, and the edge reads as the deltoid's outline.

## Other items
- **f0 near-wrist dark square:** at -105 the spot is out of view. Nothing dark shows in `near-wrist-x6-f000-f020.png`.
- **`FORE_NOLIGHT=1`:** set in every rope script.
- **Upper-arm under-layer:** `UNDER_ARM_IN=0.014`, the hammer fix, is in the keys too, for consistency.

## Files
- `pushdown-keys.jpg` (f0/f20/f48), `pushdown-f000/020/048.png` and `pushdown-keys-appsize.jpg`.
- `pushdown-hands-closeups.jpg`: both hands, clip side and from above, at f0/20/48/60. The close-ups were rendered with `UNDER_ARM_IN=0.006`, which only touches the upper arm, outside these crops.
- `camera-pair-65-vs-105.jpg`, `triceps-x6-f020-f048.png`, `near-wrist-x6-f000-f020.png`, `rope-x4-f000-f020-f048.png` and `pulley-4x-f000.png`.
- `contact-log.txt` and `framing-log.txt`.
  - The contact test ran before the boom was added. The station isn't part of that test, and the rope, cable and pulley position are identical.

No clip yet.
