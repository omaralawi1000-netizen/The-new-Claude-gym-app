# Rope Pushdown (batch 1, round 1): judge verdict

**Verdict: FIX FIRST. Do not render the clip yet.**

The choreography is real pushdown work, and so are the elbows, the hands and the twist:
- the elbows are pinned at the sides;
- the elbow table is smooth with no dead stop;
- the push is faster than the return;
- nothing is shrugged;
- the fists are clean;
- the 90-104° forearm twist holds its shape.

The staging does not work. The lockout (f45) is the frame that should teach the move, and it fails at app size. The rope does not read as split: it reads as a stick held diagonally across the hips. The pulley is out of frame, so the cable comes out of the sky beside a bare pole. The target muscle shows as a thin red sliver on the back edge of one arm. The rope prop shares every flaw found on the hammer curl, and the "rope in body" test is not sound (item 1 below, the same finding as the hammer). These are fixable with settings and the shared prop fixes, without new rig work. But the fixes change the picture enough that the stills must be judged again.

What I looked at:
- README, figure-rules.md and the EZ round-2 verdict.
- pushdown-keys.jpg, pushdown-keys-appsize.jpg, and f000/020/045 at native size and at 4x crops of the arms, hands and rope.
- All 12 panels of pushdown-hands-closeups.jpg.
- r15 frames from curl-clip-r15.mp4.
- Code: pushdown.py, render8.py (GLOW_RE, set_frame, the GRIPDIAG rope block at lines 263-335), props.py, and source/build.py, rig.py and scene.py for what UNDER is.
- There is no Blender here, so I checked the code paths and the pictures but could not re-run the numbers.

---

## Claims checked

| Claim | What I found | Result |
|---|---|---|
| Contact test: 0 hand points in the rope, every 5th frame 0-125 | The test uses a BVH of the evaluated `Rope` mesh, which is the mesh that renders, against that side's evaluated SKIN and UNDER vertices. The rope tube's normals are consistently outward, so the sign is valid. The log covers f0-125 in steps of 5. | **Real for the hands.** The segment through the fist is built every frame from the hand's own grip axis, so "0 inside" there is true by construction (hence the flat 0.3-0.4 mm clearance). The test does real work on the wraps, stoppers and strands. The rules also ask for every frame of the top and the lockout hold; here that means f44-62, and it was not run. |
| "0 rope points inside body/arms" | Rope vertices are checked against **UNDER** with a face-normal sign (render8.py:302). UNDER holds the Z-Anatomy region *skin sheets*, merged into `U:body` and `U:arm region.*` and sunk under the muscles. build.py:132 notes "mixed winding, so no normals", and nothing later recalculates them. The visible **MUS** muscles and **EggHead** are not tested. The cable is sampled about every 13-20 cm. | **Not proof.** In the pictures, at f45 the near strand crosses in front of the hip with no visible cut. Even so, the method cannot be trusted, and the new staging (item 3) puts the clip and strands near the face at the top, which nothing tests today. |
| Hand vs trunk/legs, gap 162 mm | Ray parity along +z on the open `U:body` sheet (arm holes and crotch cut), so the inside count is unreliable. The gap is a real distance to the under-sheet. "1000000000000mm" is a sentinel meaning nothing within 200 mm. | The gaps are believable. In f45 the near hand only overlaps the thigh in screen space. Agreed: it is camera overlap. |
| Knobs away from the pulley | `rope_high` → 'thumb' entry → the rope leaves the thumb side and the stoppers sit at the pinky side. They sit under the fists at f0 and f20 and behind the fists at f45. | **True.** The docstring at props.py:194-195 says the opposite. Fix the comment. |
| Glow on the three triceps heads | `GLOW_RE = 'triceps brachii'` matches all the heads, and the biceps no longer glow. In the image only the near arm's posterior edge glows: a strip about 25 x 60 px at 960, roughly 10 x 25 px on a 384 px app stage. The far triceps is hidden. The `bt` band (lit 0.17-0.47 from the elbow) was tuned for the biceps, so the upper long and lateral heads stay grey. | The right muscles, but it **does not read clearly** at app size (item 4). |
| Own choreography, no dead stops | pushdown.py is its own file. The elbow is a per-frame table with sigma 3: push f0-44, creep into lockout f44-60, return f60-112, and a soft turn at the top. The loop seam is 89.4 → 89.3. The return is slower than the push. | **True for the elbow.** `twist`, `abduct`, `pelvis_pitch` and `shoulder` are cosine keys with **flat holds** at (40→54) and (36→54). The split and turn-out of the hands **stop dead for 14 frames** while the elbow is still creeping (item 5). |

## Must fix before the clip

### 1. Shared rope-prop fixes, the same as the hammer curl (every frame)
- **What is wrong:**
  - The rope is a smooth tube in the body's own clay, so it reads as a metal V-handle or pipe.
  - The 17 mm wraps make pipe-elbow kinks. Examples: f0, near hand, where the strand leaves the top of the fist with a hard kink of about 130°; and f45, both hands, where the rope runs flat through the fist and then bends 90° up.
  - The stoppers are pawn- or vase-shaped: props.py:239, where the sine profile drops back to 0.75R after u=0.032 and the end is a flat cap.
- **Fix:**
  - A charcoal braided rope, about 35-45% of the clay's albedo with a three-strand bump. Show Omar an A/B against clay on one still.
  - Black rubber stoppers: a rounded cylinder about 44 mm long, radius about 21 mm, with a domed end.
  - A 30-40 mm wrap radius, with the bend starting inside the hand span when the turn is over 100°.
  - A small eye or carabiner at the clip.

### 2. Lockout (f45): the rope does not read as split, and it reads as a stick across the hips
- **What is wrong (p45 at 4x and the app-size strip):**
  - The near strand runs from the near fist diagonally across the hip to the clip, which sits up beside the far forearm.
  - The far strand is foreshortened to a stub.
  - Both fists hold the rope flat and front-to-back, with the stoppers behind them.
  - At app size this is "holding a bar diagonally in front of the thighs". The V that should open round the thighs is not there.
- **Cause:**
  - The pulley sits 0.69 m in front of him at 1.98 m (props.py:125-127). The clip slides 0.38 m along the line from the hands to the pulley, so at lockout the V points forward and up, at about 30-35° off vertical, and the camera sees it nearly edge-on.
  - The turn-out is only 14° past neutral.
- **Fix:**
  - **Bring the pulley closer:** its foot should be about 0.40-0.45 m in front of the feet (`COL` y about -0.55 / `HIGH` y about -0.45), with the high pulley at about 1.90 m. The cable then runs within about 15° of vertical at lockout, and the rope hangs as an inverted V under the clip, which is the classic pushdown silhouette.
  - **Shorten the strands** to about 0.26-0.28 m from the exit to the clip (`ROPE_STRAND`; a standard 27-inch rope). At f0 today the clip sits at eye level, about 40 cm above the fists; real ropes put it about 20-25 cm above. figure-rules.md fixes 0.38 m, so this is a rules change. Show it on the A/B still.
  - **Turn-out:** `twist` 90 → **118-122** at lockout (palms facing back and down, knuckles out), up from 104.
  - **Split:** `abduct` to **6-7°**, so the fists finish beside the thighs, not in front of them. Today it is 9° but starts at f16, which moves the elbows off the ribs mid-push (see item 5).
  - Check that the stoppers then sit beside or behind the thighs and clear them by at least 3 cm, using the corrected test (item 6).

### 3. The pulley is out of frame: the cable comes from nowhere beside a bare pole (f0-f45)
- **What is wrong:** the cable leaves the top edge about 55 px left of the column, and nothing connects them. The column reads as an unrelated grey pole that dominates the right third at app size.
- **Fix:**
  - With item 2's closer, lower pulley (about 1.90 m), check whether the carriage and wheel come into frame. If they don't, add a short top arm or housing so the cable visibly goes *to* the column.
  - Make the station recede for both cable moves: about 1.5-2 values lighter than the clay, with lower contrast.
  - Make the wheel read as a pulley: about 1.5x the current 42 mm wheel, with visible cheek plates. The scale is otherwise right: a 9 cm upright, 2.3 m tall.

### 4. The triceps glow does not read clearly at app size (every frame)
- **What is wrong:** from the cable camera (orbit -38°) we see his front-right. The triceps is on the back of the arm, so only a thin strip of the near lateral and long heads shows. The movers of a triceps exercise must be the first thing the eye lands on, as the biceps are in r15.
- **Fix, in this order:**
  - **(a) Camera:** for the pushdown only, test cam_orbit **-65° and -80°**, which puts the camera more to his right side. The whole lateral head and the long head face the camera, the forward lean finally reads (the README admits it barely reads now), and the column still stands beside him. Pick the angle where the triceps *and* the split (item 2) both read. This departs from the "about -38°" cable rule, so put the A/B in front of Omar.
  - **(b) Triceps glow band:** widen the lit band for objects matching `triceps` to about bt 0.12-0.75, so the horseshoe of the long and lateral heads glows, not just a lower-middle band. Keep the biceps' approved band as it is.

### 5. Hand split and turn-out stop dead at lockout (f40-54)
- **What is wrong:**
  - `twist` (40,104)→(54,104), `abduct` (40,9)→(54,9), `pelvis_pitch` (40,-6.3)→(54,-6.3) and `shoulder` (36,10.5)→(54,10.5) are flat holds under cosine easing, so the hands freeze for 14 frames.
  - The turn and split also start at f14-16, when the forearm is still near level. Coaches cue them at the bottom: "push, then split and turn".
- **Fix:**
  - Start `twist` and `abduct` at about f24-26 and peak at f48.
  - Then creep them, for example twist (48, 116) → (60, 120), and abduct (48, 6) → (60, 7), returning by f90.
  - Give the body holds a small creep the way the curl's do, for example pelvis -6.3 → -6.1.

### 6. Make the contact test prove the body side (render8.py:293-332)
- Test the rope against what renders: MUS, SKIN, UNDER and EggHead.
- Use **unsigned** distance from rope *centreline* samples every 5 mm along the strands, clip and cable. Pass when the distance is at least ROPE_R (or KNOB_R along a stopper), except inside the fist.
- Add the same side's forearm MUS to the hand-vs-rope check.
- Run it every 5th frame plus every frame of the lockout (f44-62) and the top turn (f112-129, f0-5).
- Print ">200mm" in place of the 1e12 sentinel.
- This must run *after* items 2-3 move the clip toward the face at the top.

## Should fix (same pass)
7. **Forward lean:** the claimed 10-12° is real in the keys (pelvis -6.3, lumbar -3, chest -2.5). Judge it again after the camera change. If it still barely reads, go to about 14° total. Do not go further: past that it becomes a press-down.
8. **Wrist:** stays at 2°. Good. At the stronger turn-out from item 2, check the forearm close-up for any candy-wrapper. At 104° there is none: the spiral of the forearm muscles at f45 reads as real pronation.

## Passed / accepted
- **Elbows pinned:** the upper arm is about vertical with the elbows at the ribs at f0, f20 and f45. The 4.5° forward drift at the top and the press back at lockout are correct coaching.
- **Range:** from forearms a touch above level (elbow 89°) to full lockout at 7.5°, never hyperextended.
- **Nothing shrugged:** scap is set at 0.95 and the shoulders sit level and down.
- **Tempo:** about a 1.5 s push, a creep into lockout, a 1.7 s return and a soft turn at the top. No dead stop on the elbow, and the loop seam is clean.
- **Hands:** in all 12 close-ups the fingers wrap the rope, nothing passes through a finger, and the stoppers sit at the pinky side. The quality is the same as r12/r15. The dorsal wrist cuff with tendon gaps shows only from above and is not visible at 960, the same accepted limit.
- **f20** is the best frame of either rope move: the V, the fists and the pinned elbows all read like a real pushdown.

## Worse than r15
1. **The prop** (item 1), the pole and the floating cable (item 3): this is far below r15's product-shot barbell.
2. **The glow:** r15's red biceps face the camera, while here the movers are a thin edge strip (item 4).
3. **The lockout key frame does not read as the exercise** (item 2).
4. The body, light and skin are unchanged and not worse.

## Can the clip render go now?
**No.** Fix items 1-6 (7-8 in the same pass). Then render the three keys at the chosen camera, plus the -65° and -80° A/B, and the hand close-ups at f0, f20, f45 and f60, plus one still of rope material A/B. Save the contact log and get a re-judge. Then render one clip.
