# Rope Pushdown: round 1 stills

## Files
- `pushdown-keys.jpg`: f0 (top: forearms a little above level), f20 (mid push), f45 (lockout, rope split).
- `pushdown-keys-appsize.jpg`: the same at about app size.
- `pushdown-f000/020/045.png`: full size.
- `pushdown-hands-closeups.jpg`: rows are f0, f20 and f45. Columns are the right hand (clip view, from above) and the left hand (clip view, from above).
- `contact-log.txt`: the contact test, every 5th frame 0-125.
- `pushdown.py` (choreography), `render8.py` and `props.py` (build).

## What it is
- **Own choreography** (not the curl's), written from how a strict rope pushdown is done:
  - hips back 2.5 cm and the trunk leaning about 10° forward from the hips, chest up, knees soft at 12°;
  - upper arms about vertical with the elbows by the ribs (shoulder flex 10-15°, matching the lean);
  - elbows 90° at the top down to full lockout (7.5°, never hyperextended);
  - the rope splits at lockout: the straight arms angle out to 9° and the palms turn about 14° past neutral.
- **Timing**: the elbow is a smoothed per-frame table (sigma 3 frames) with no dead stops.
  - Push over frames 0-44 (1.5 s).
  - Creep into lockout over 44-60, with a small extra squeeze.
  - Return over 60-112 (1.7 s, slower than the push).
  - Soft turn at the top over 112-130.
  - One breath per rep: breathe out on the push.
- **Rope held the real way**: the knobs sit on the side of the fist away from the pulley. On a high pulley that means the rope leaves the thumb side and the knobs sit under the pinkies.
- **Glow is on the movers**: all three triceps heads (the curl's biceps glow is off).
- **Camera** is the same as for the cable curls: turned -38° so the column stands beside him.

## Contact test (log in contact-log.txt)
- Hand skin inside the rope: **0 on every frame**, worst clearance +0.3 mm.
- Rope inside the body or arm hulls: **0**.
- New: hand skin against the trunk and legs, using ray parity on the body hull: **0 inside**. The smallest gap is 162 mm, at lockout.
  - In the f45 clip-view close-up the right hand only looks as if it sits on the thigh. That is camera overlap.

## Known, for the judge to rule on
- The trunk lean (about 10°) barely reads from this 3/4 camera.
- The pulley and the top of the column are out of frame: the cable leaves the top edge.
- The wrist-skin edge shows in extreme close-ups, the same as on the approved r15 curl.
