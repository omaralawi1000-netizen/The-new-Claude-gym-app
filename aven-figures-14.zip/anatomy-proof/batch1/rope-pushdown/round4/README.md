# Rope Pushdown, round 4 (fixes for judge round 3)

Round 3 files are in `round3/`; the verdict is `judge-verdict-r3.md`. Code: `../code-r5/` (shared with the hammer).
Logs: `rope17.sh` (contact, cable, far end, framing), `rope19.sh` (keys, the -105 and -65 stills, close-ups), `camtry*.sh` (camera trials).
Everything below is self-checked, not judged.

## Camera: -115, not -105 (flaw 3, cable)
- **New check, `CABLEDIAG`:** along the projected cable (1 px steps), rays across it give the signed distance to the figure's
  outline. A visible stretch of cable within 6 px of the outline for more than 24 px counts as TANGENT.
  It reproduced your finding at -105: a 27-37 px graze along the near deltoid at f40-68 (`camera-trials-log.txt`, camtry7).
- **What I tried, as you listed:** -95, -100, -110, -115, -120, -125, +3 deg lift (0.20 m) at -105 and -110, the pulley 8 cm
  further out (HIGH_Y 0.52/0.60/0.68) and 8 cm to either side. At -95 to -110 the cable still runs along the deltoid or the
  back of the arm: the cable and the upper arm are both near vertical there, so any crossing is shallow.
- **What worked:** -115. The cable drops behind the neck-shoulder gap, your fallback, and crosses the trapezius steeply
  (near-outline runs of 1-3 px). `cable-x3-f048-105-vs-115.png` shows both.
- **`cable-log.txt` (every 2nd frame of 130):** 0 tangent frames in f30-80. Three tangent frames remain at f24, f26 and f84,
  where the cable sweeps across the deltoid edge as the clip passes the shoulder line (26-38 px). That is a crossing in motion,
  1-2 frames each way; flagged for the clip.
- **The column:** at -115 the pole came within 11 px of the near fist, so it now stands 1.3 m out (`COL_HIGH_Y`, default now)
  on a longer boom. The pulley itself has not moved (0.44 m out, 1.80 m up).
- **`framing-log.txt`:** the near fist is at least 48 px from the column on every frame, the midpoint is -11..-2 px from x 480,
  the top margin is 36 px and the base margin 42 px.
- **Camera cost:** the elbow arc is about 10 deg less in profile than at -105. Both triceps still face the camera.
  `camera-f048-65-105-115.jpg` shows f48 at all three (the -65 still is for Omar's comparison).
- `cam_orbit -115` is baked into `pushdown.py` (judge minor), so a script without `CAM_ORBIT` renders the right camera.

## Far stopper (flaw 3b)
- **New check, `FARDIAG`:** around the far end cap it counts visible cap pixels and visible far-fist pixels. It passes if the
  cap is hidden, or the fist visibly holds it (150 px or more).
- **Hiding the cap failed:** with a split of 4-8 deg the cap pokes out beside the far hip and the fist stays behind it.
- **Showing the fist worked:** the lockout split is now 2/10/11/12/10/2 deg at f20/36/48/60/76/100 (was 2/6/7/2 at
  f26/48/60/90). From f40 to f68 the far forearm and fist show past the hip holding the end (`rope-x4-...-f048far-...png`).
- **`far-end-log.txt`:** 0 floating frames in f40-68. In motion the cap leads the fist by 2-3 frames as the hand comes round
  the hip (f34-38) and trails it on the way back (f70-76). Flagged for the clip.
- **This needed a longer rope.** With 0.33 m strands, a split over about 8 deg could not be spanned, and the V went flat (clip
  11 mm above the exits). Strands are now **0.40 m** for this move (a 36-inch rope, a common size). The hammer stays at 0.33 m.

## The rope V and contact (shared strand builder, judge minor)
`contact-log.txt`: 90 frames, every 2nd frame plus every frame of f30-80.
- **Hands:** 0 hand-skin points inside the rope; worst clearance 0.3 mm.
- **Straightness and pull:** ROPESTRAIGHT worst 0.00 mm, and ROPEMONO 0 violations (worst back-step 0.0 mm).
- **Rope vs body and head:** 0 crossings, rope-to-body at least 5.9 mm, rope-to-head at least 129 mm.
- **Clip height:** at lockout the clip is at least **192 mm** above the rope exits (worst f59). At the top it is 374 mm above
  the fists.
- **New strand builder (from the hammer fix):** each strand is a 32 mm arc at the fist edge, then a straight line to the sleeve.
- **Clip solve:** it now takes the farthest clip position along the cable, scanning down from the top. On the hammer this
  changes nothing at the 5 frames I compared.
- **Fist tilt:** pushdown default 8 deg, one default per prop in `render8.py`. `tilt-log.txt`: max |2nd diff| 0.017 deg/f².

## Triceps: two heads (flaw 1)
- **Dropped:** `GLOW_FACE_MIN`, `GLOW_EMIT 0.055` and `GLOW_AO`. The glow is back to the curl's settings.
- **New, `GLOW_OUTLINE=0.45`:**
  - Each glowing head writes its own id to an AOV (`gid`: lateral 0.25, long 0.5, medial 0.75).
  - A Sobel edge of that AOV, thresholded (`OUTLINE_T=0.4`) and limited to the glow mask, darkens the final image along the
    head borders.
  - The line is 1-2 px, with about 45% strength at its centre.
- **Your pick (442,225)/(444,245) at f48:** it is the long head of the **biceps**, seen past the arm, so it stays unlit.
- **`triceps-x6-f020-f048.png`:**
  - At 1x a darker line runs between the long and lateral heads at f20 and f48, and at x6 each head has its own outline.
  - The line has a small step where one mesh overlaps the other. That is geometry, not aliasing.

## Red (flaw 2)
`colour-log.txt` uses one script for all three moves, with the approved curl re-rendered as the reference. My numbers differ in
absolute terms from yours (you had a core of about 229/64/46), so read the rows against each other.

| Move | Core | Lightness |
| --- | --- | --- |
| Curl f30 / f55 | 220/52/35, 220/45/29 | 0.543 / 0.533 |
| Hammer f0-55 | 220-222/47-49/31-32 | 0.544-0.554 |
| Pushdown f0/20/48 | 224-227/49-51/31-33 | 0.551-0.555 |

- **Lightness:** within 0.02 of the hammer, and within 0.022 of the curl's darker f55 key.
- **Core:** G and B are within 3 of the hammer. R is 2-7 higher, a slightly more saturated red.
- **How I got there:** `GLOW_EMIT 0.09` for this move; the scene default is 0.08 and the shared colour is unchanged. With the
  outline, 0.08 came out a little dark (lightness 0.545).

## Minor
- **Creeps:** `breath` 0.15 → 0.12 over the squeeze (f38-52) and `brace` 1.0 → 0.97 (f20-54).
- **Cable look:** r 4 mm, matte (Specular IOR Level 0.05). On the hammer keys it measures 100-115 grey against a 238 background (same material here).
- **Framing script:** it is in `code-r5/rope17.sh`, the CAMDIAG line.
- **Upper-arm under-layer:** it is also pulled in 4 mm just past the elbow (`UNDER_FORE_IN`, the hammer's speck fix). Nothing
  changed visibly here.

## Files
- **Keys:** `pushdown-keys.jpg`, `pushdown-f000/020/048.png`, `pushdown-keys-appsize.jpg`.
- **Close-ups:** `pushdown-hands-closeups.jpg`, both hands at f0/20/48/60, clip side and from above.
- **Camera and cable:** `camera-f048-65-105-115.jpg`, `cable-x3-f048-105-vs-115.png`.
- **Crops:** `triceps-x6-f020-f048.png`, `rope-x4-f000-f020-f048far-f048near.png`.
- **Logs:** `contact-log.txt`, `cable-log.txt`, `far-end-log.txt`, `framing-log.txt`, `tilt-log.txt`, `colour-log.txt`,
  `camera-trials-log.txt`.

No clip yet.
