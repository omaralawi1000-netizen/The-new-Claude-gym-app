# Judge verdict clip5-r9-side: FAIL (rest 8.0, motion 7.5, rope 7.0)
Main reason: at lockout (f30-f90) the rope still reads as one rigid triangular frame (a V-handle / bent wire), not soft rope, and the arms never reach lockout (elbow stays clearly bent).

Viewed: keys-sheet, figure-x2 (f20/48/72/100), and final frames f0,5,10,11,20,27,28,29,30,31,36,40,48,50,60,70,72,73,79,80,81,82,83,90,100,101,107,108,109,110,111,112,113,120,129 as 1.5x crops, plus 4x crops of f60 and f100 hands. Not viewed: the other ~95 frames, the mp4 (cannot play).

## Scores
Rest/stills 8.0, motion plausibility 7.5, rope realism 7.0.

## Checks
- Camera fix works: clip, cable and pulley are visible in every frame; V apex is seen. Big improvement over r8. Cable is taut and straight, clip reads as a clip.
- Rope: strands have twist texture but are uniform, dead straight rods. At f30-f90 the near strand runs straight down then makes a sharp round "hook" bend at the near fist (~(330,360) full-frame at f60), the far strand is a straight rod to the far fist, so the pair closes into a TRIANGLE with the clip. It looks like a rigid triangle pull-down handle. No sag, no curve, no slack.
- Hands/knobs: knobs sit under the pinkies, look like stoppers (acceptable). Near fist wraps well at f0-f20/f100-f129. At f36-f80 the near knob sticks out past the pinky as a long dark cylinder (f48 ~(385,390), f80 ~(350,375)): reads like a handle end.
- Far fist: far strand end is visibly held at all times; the far fist is tucked behind the near hand at lockout (f40-f83) and only the knob shows. Not floating. OK.
- Forearm vs rope: near forearm passes in front of the near strand at f40-f80 with a clean overlap. No pass-through seen.
- Slivers at 100%: f5,11,27-31,79-83,100,101,107-113 all viewed. No pink slivers or white pinholes seen. Far-forearm shows as a dark thin band behind the elbow at f100/f101/f11 (~(300-330,235-250) full-frame); it reads as a dark stripe, slightly odd but not a glitch. Far forearm at f27-31/79-83 is a sharp dark wedge behind the torso, acceptable.
- Column/base: clean, no specks in the keys. Glow: strong, head separation fine, soft edge halo, looks good.
- Trunk still, head level, loop looks smooth in stills (no motion viewed).

## MUST-FIX
1. f30-f90 (esp. f36-f80): rope is a rigid triangle. Give the strands a slight curve/slack and a soft wrap round the fist instead of a straight rod plus sharp hook at ~(330,360) f60. Make the near strand leave the thumb side and hang, not bend back as a tight angle.
2. f36-f80: arms are not locked out. Elbows still bent roughly 40-50 degrees with forearms angled down; real lockout is near straight and hands split a little. Extend further (hands lower/outward).
3. f36-f80: near knob projects past the pinky as a bar end (f48 ~(385,390); f73 ~(355,375)). Shorten/tuck it.
4. f100/f101: dark far-forearm band behind the elbow (~(300-330,240)); soften it or hide it.

## Nice-to-have
Thinner strands near the fist; subtle strand tilt differences at the V; slightly stronger pulley highlight.

## Verdict: FAIL (below 9). Fixed the visibility problem but the lockout rope still looks like a rigid frame.
