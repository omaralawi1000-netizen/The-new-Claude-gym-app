# Judge verdict clip7-r11: FAIL (stills 8.4, motion 8.5 from stills only, rope 8.0)
Main reason: the far-forearm dark wisp is NOT gone (f11-18 and f90-96 still show a dark hair-like wedge behind the elbow), the far strand is a flat dark wire at lockout, and tiny light flecks sit at the near-fist/rope junction f33-f72.

Viewed (final frames, 3x crops, plus 6x on fist): f0,5,8,11,15,18,20,24,27,30,33,34,36,40,45,48,55,60,66,72,76,78,80,84,90,94,96,100,101,105,106,110,115,120,125,129 (36 frames). mp4 not played. Full-frame coords below (960x640).

## Earlier must-fixes
1. Near knob bar-end: FIXED. Now a short boxy nub (f48 ~(262-275,372-388)); no longer a bar end. New nit: at lockout it is a cube sitting beside the fingers, reads like a tiny weight, not a rope end. Small.
2. Hard corner at near fist and lost twist: MOSTLY FIXED. Bend is now a clear round curve (f36-f80 ~(300-345,345-375)); near strand keeps visible twist at lockout. Good.
3. Dark far-forearm wisp: NOT FIXED. f90 ~(330-363,275-290), f94/f96 ~(330-357,275-283), f15 ~(333-363,272-280), f11 faint ~(330-353,270-275), f18 bigger ~(330-363,273-293). At f20-27 it reads as a real far forearm (striations), fine. At f11-15 and f90-101 it is a thin dark pointed streak sticking out behind the elbow, like hair/smudge. f100/101 only faint.

## New problems from the changes
- Far hand lower at top: not odd, not lopsided. Fists overlap naturally at f0-8 and f105-129. No complaint.
- Knob/rope interpenetration: none seen. Knob is detached-looking from rope at lockout because the rope disappears behind the hand and the knob appears on the other side (f48 rope end ~(300,372), knob ~(268,380)); plausible, but a viewer may read it as a floating cube. Taste-level.
- Rounder bend: no crossing of thigh (clear gap). It does pass over the hand's edge at wrist (f36-f80) cleanly. Fine.
- Near hand at f76-f84: fingers point down and look open/dangling beside the knob, not wrapped on the rope (f80 hand ~(320-360,330-365)). Grip reads weak for ~8 frames.

## Slivers / specks (flagged frames viewed: 8,33,34,76,78,80,94,101,105,106)
- No pink slivers. No big pinholes.
- Tiny light flecks at rope/hand junction: f33 white dot ~(347-350,347-351); f60 dashed light edge ~(328-335,347-357); f72 pale patch ~(343-348,345-352); f36 dashes ~(340-345,352-355). 3-6 px; visible at 6x, faint on phone but they flicker in motion. MUST-FIX (Omar bans pinholes).
- Frames 8, 76-80, 94, 101, 105, 106: clean apart from the wisp above.

## Far fist holding its strand: OK at all frames. Glow: OK, soft, strong separation. No floating.

## Rope realism
- Straight cable-to-fist run: physics-right, not marked down.
- What still reads as wire: (a) far strand (right side of triangle, f27-f90) is a uniform dark rod, no twist, and has a tighter bend at the far hand (f36 ~(365-372,330-340)); near strand has twist, so the two strands look like different materials; (b) strands same thickness to the end; (c) closed triangle shape of V-bar. Fixes: give the far strand the same lay texture and a lighter value; thin both 15-20% over the last 100 mm; a hint of slack at f0-10 and f120-129.

## MUST-FIX
1. f11-f18 and f90-f96 (also faint f100/101): dark far-forearm wisp ~(330-363,272-290). Lighten to skin tone, shorten, or hide behind torso.
2. f33-f72: light flecks at rope/fist junction (coords above); fill them.
3. f27-f90: far strand flat dark, no twist (~(360-380,270-350) at f48). Give it the near strand's texture.

## Nice-to-have
Round the cube knob (soft cap, slightly smaller); close the near fingers on the rope at f76-84; thinner strands at fist.

## Taste / phone-invisible
Cube knob shape, finger posture f76-84, strand thickness, rope slack: a normal viewer on a phone would not notice these. The wisp at f90-96 and the dark far strand are the two a normal viewer might notice (a dark streak at the shoulder, a "metal" side of the triangle).

## Verdict: FAIL (below 9). Big gains (knob, round bend, texture at near fist); wisp unchanged in effect, far strand wire-like, small flecks remain. One more small round should get 9.
