# Gate report: pushdown

**GREEN: ready for the judge** (0 fail, 13 pass, 2 for a human eye)

- PASS  Pixel stage ran on every frame (holefill3 made all final frames): raw 130, final 130
- PASS  No diagnostic job crashed: none
- PASS  Hands on the prop (contact): inside 0, worst clearance 0.3 mm
- PASS  Rope strands run only toward the clip: 0 strand-frames
- PASS  Rope straight past the fist: 0 strand-frames
- PASS  Far rope end held (nothing floating): 0 floating frames
- PASS  Cable clear of outlines: tangent runs 0, longest 0 px
- PASS  Fist tilt smooth (<= 0.15 deg/f^2): max 0.126
- PASS  Near fist clear of the machine: worst gap 230 px at f100
- INFO  Far-limb slivers (judge decides size): frames 8,35,77,80,101,33,78,105,34,76,79,94,106
- PASS  Background specks after the fill (speck2h): 0 frames
- INFO  Dimmed gap ends (check in sequence): frames 22,23,24,29,30,31,32,33,34,88
- PASS  No pops or flicker (clipcheck): []
- PASS  Motion smooth, no hitch (blurred steps): SMOOTH steps 130 median 0.551 max 1.539 | seam 0.093 vs neighbours 0.122 | spikes none
- PASS  Pixel scans saw every frame: speck2h 130 frames, clipcheck "frames N" ok

Logs and crops: this folder. Final frames: ../pushdown_final/
