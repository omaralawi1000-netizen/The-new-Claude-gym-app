# Gate report: pushdown

**GREEN: ready for the judge** (0 fail, 13 pass, 2 for a human eye)

- PASS  Pixel stage ran on every frame (holefill3 made all final frames): raw 130, final 130
- PASS  No diagnostic job crashed: none
- PASS  Hands on the prop (contact): inside 0, worst clearance 0.3 mm
- PASS  Rope strands run only toward the clip: 0 strand-frames
- PASS  Rope straight past the fist: 0 strand-frames
- PASS  Far rope end held (nothing floating): 0 floating frames
- PASS  Cable clear of outlines: tangent runs 0, longest 4 px
- PASS  Fist tilt smooth (<= 0.15 deg/f^2): max 0.135
- PASS  Near fist clear of the machine: worst gap 34 px at f60
- INFO  Far-limb slivers (judge decides size): frames 11,14,17,20,26,29,32,35,38,41,44,47,50,53,56,59,62,65,68,71,74,80,83,89,92,95,98,9,12,15,18,33,36,39,42,45,48,51,54,57,60,63,66,69,72,75,78,87,90,93,96,99,129,7,10,13,16,19,28,31,34,37,40,43,46,49,52,55,58,61,64,67,70,73,85,88,91,97,100,121
- PASS  Background specks after the fill (speck2h): 0 frames
- INFO  Dimmed gap ends (check in sequence): frames 12,14,28,83,84,85,96,97,98
- PASS  No pops or flicker (clipcheck): []
- PASS  Motion smooth, no hitch (blurred steps): SMOOTH steps 130 median 0.399 max 1.267 | seam 0.164 vs neighbours 0.162 | spikes none
- PASS  Pixel scans saw every frame: speck2h 130 frames, clipcheck "frames N" ok

Logs and crops: this folder. Final frames: ../pushdown_final/
