# Judge verdict clip4-r8: FAIL (rest 7.5, motion 7)
Main reason: at lockout (f36-f90) the rope reads as ONE rigid bent pole behind the back, not a soft rope with a V.
Evidence (f48, f72): two straight, uniform dark rods, no sag/curve, each ~100 px long, joined behind the torso near (415,285); the clip/cable meet is hidden behind the head/back so the V apex is never seen. Near strand runs from near fist (295,372) up-right into the back at ~(340,320); far strand emerges at ~(415,285) down to far fist (472,378). Together it reads as a single diagonal bar. Far rope end at (470,378) sticks out as a bar end with a knob.
MUST-FIX
1. f36-f90: rope = rigid rod. Needs a visible apex (clip) and a soft curve/slack; strands thinner, with rope twist texture; do not let both pass behind the torso as one line.
2. f36-f90: cable ends at ~(410,182) behind the head/shoulder and the clip is never visible, so the rope seems to start from the spine.
3. f48/f72: near-fist rope end projects past the pinky (~(295,372)) like a bar end; knob looks like a metal cap, not a stopper under the pinky. Far fist same.
4. f100-f110: far fist hangs holding a short stub with a small black stopper (hands zoom, 4th panel); rope nearly vanishes, reads as a dumbbell/weight hanging, strands not seen going up to the clip.
5. Gate green is misleading: "strands toward clip" passes but the look is a pole. Far-limb sliver list is 80+ frames (INFO); verify not visible pink bits at 100% before shipping.
GOOD: f0 rest looks right (narrow V, clip and cable visible, hands at lower chest); column/base clean, no specks seen, glow strong and even, elbows pinned, trunk still, smooth loop.
NICE: stronger pulley highlight, softer glow edge halo on shoulders, base wedge looks flat.
Not checked at pixel level: every frame; I viewed f0, f48, keys sheet, hands zoom.
