# hammer r8 pinhole pass: ray masks (POCKETDIAG) -> holefill3 (closed pockets filled, gap tails dimmed 0.6) -> holefill2 (4 notches)
R=../bpyenv/bin/python; mkdir -p bgm
for k in 0 1 2 3; do env MOTION=hammer POCKETDIAG=1 POCKET_OUT=$PWD/bgm POCKET_BOX=300,100,500,420 FRAMES_SUB=$(seq 0 129 | awk -v k=$k 'NR%4==k' | paste -sd,) $R run5.py scene12.blend render8.py -- still /dev/null 0 > /dev/null 2>&1 & done; wait
python3 holefill3.py clip_hm4 clip_hm4x bgm 0 129 300 100 500 420
cp -r clip_hm4x clip_hm4w; for f in 30 48 92 97; do python3 holefill2.py clip_hm4x tmpfill $f $f 300 100 500 420; cp tmpfill/f$(printf %03d $f).png clip_hm4w/; done
python3 holefill2.py clip_hm4w tmpfill 92 92 300 100 500 420; cp tmpfill/f092.png clip_hm4w/
